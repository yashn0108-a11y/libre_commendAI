"""
AI-Based Smart Library Recommendation System
Course: V Semester ETC - Natural Language Processing (ET5M004)
"""
