"""
Recommendation Module for AI-Based Smart Library Recommendation System
Course: V Semester ETC - Natural Language Processing (ET5M004)

This module implements:
1. TF-IDF Vectorizer from scratch using pure Python and standard library math
2. Vector space representation for library books and user queries
3. Cosine Similarity measurement between vectors
4. Ranking and Top-N recommendation generation
5. Edge-case and error handling
"""

import math
from collections import Counter
from typing import List, Dict, Any, Tuple
from .preprocessing import preprocess_text, preprocess_with_steps


class TFIDFVectorizer:
    """
    Term Frequency - Inverse Document Frequency (TF-IDF) Vectorizer.
    
    Uses standard smoothed IDF formula:
    IDF(t) = ln((1 + N) / (1 + DF(t))) + 1
    
    Followed by L2-norm normalization so that Cosine Similarity is
    the dot product between normalized unit vectors.
    """

    def __init__(self, lowercase: bool = True, filter_stop: bool = True, stem: bool = True):
        self.lowercase = lowercase
        self.filter_stop = filter_stop
        self.stem = stem
        self.vocabulary: Dict[str, int] = {}
        self.idf_: Dict[str, float] = {}
        self.num_docs: int = 0

    def fit(self, raw_documents: List[str]) -> "TFIDFVectorizer":
        """
        Builds vocabulary and computes IDF scores from the corpus of documents.
        """
        self.num_docs = len(raw_documents)
        df_counts = Counter()

        # Preprocess each document and count document frequencies
        doc_tokens_list = []
        for doc in raw_documents:
            processed = preprocess_text(
                doc,
                lowercase=self.lowercase,
                filter_stop=self.filter_stop,
                stem=self.stem
            )
            tokens = processed.split()
            doc_tokens_list.append(tokens)
            unique_terms = set(tokens)
            for term in unique_terms:
                df_counts[term] += 1

        # Build vocabulary sorted by term for deterministic indexing
        sorted_terms = sorted(df_counts.keys())
        self.vocabulary = {term: idx for idx, term in enumerate(sorted_terms)}

        # Compute smooth IDF: ln((1 + N) / (1 + DF)) + 1
        self.idf_ = {}
        for term, df in df_counts.items():
            self.idf_[term] = math.log((1 + self.num_docs) / (1 + df)) + 1.0

        return self

    def transform(self, raw_documents: List[str]) -> List[Dict[str, float]]:
        """
        Transforms documents into normalized sparse TF-IDF feature dictionaries.
        Each vector is represented as a dictionary {term: tfidf_weight}.
        """
        vectors = []
        for doc in raw_documents:
            processed = preprocess_text(
                doc,
                lowercase=self.lowercase,
                filter_stop=self.filter_stop,
                stem=self.stem
            )
            tokens = processed.split()
            if not tokens:
                vectors.append({})
                continue

            tf_counts = Counter(tokens)
            total_terms = len(tokens)

            # Calculate raw TF-IDF for known vocabulary terms
            doc_vector: Dict[str, float] = {}
            norm_sum_sq = 0.0

            for term, count in tf_counts.items():
                if term in self.vocabulary:
                    tf = count / total_terms
                    idf = self.idf_[term]
                    tfidf = tf * idf
                    doc_vector[term] = tfidf
                    norm_sum_sq += tfidf * tfidf

            # L2 Normalization (Euclidean norm)
            l2_norm = math.sqrt(norm_sum_sq)
            if l2_norm > 0:
                doc_vector = {k: v / l2_norm for k, v in doc_vector.items()}

            vectors.append(doc_vector)

        return vectors

    def fit_transform(self, raw_documents: List[str]) -> List[Dict[str, float]]:
        """Fits vocabulary and returns transformed document vectors."""
        self.fit(raw_documents)
        return self.transform(raw_documents)


def compute_cosine_similarity(vec_a: Dict[str, float], vec_b: Dict[str, float]) -> float:
    """
    Computes Cosine Similarity between two L2-normalized sparse vectors.
    Since ||A||_2 = 1 and ||B||_2 = 1, Cosine Similarity is simply the dot product:
    Cosine_Sim(A, B) = sum(A[i] * B[i])
    """
    if not vec_a or not vec_b:
        return 0.0

    # Iterate over the smaller vector for maximum efficiency
    if len(vec_a) > len(vec_b):
        vec_a, vec_b = vec_b, vec_a

    dot_product = sum(weight * vec_b.get(term, 0.0) for term, weight in vec_a.items())
    return round(float(dot_product), 4)


class LibraryRecommender:
    """
    AI-Based Smart Library Recommendation Engine.
    
    Orchestrates:
    - Preprocessing
    - TF-IDF Vectorization
    - Cosine Similarity Matching
    - Ranking & Dynamic Recommendation Generation
    """

    def __init__(self, books: List[Dict[str, Any]]):
        self.books = books
        self.vectorizer = TFIDFVectorizer(lowercase=True, filter_stop=True, stem=True)
        self.book_vectors: List[Dict[str, float]] = []
        self._initialize_corpus()

    def _initialize_corpus(self):
        """Preprocesses book combined metadata and fits the TF-IDF vectorizer."""
        corpus = [b["combined_text"] for b in self.books]
        self.book_vectors = self.vectorizer.fit_transform(corpus)

    def recommend(
        self,
        query: str,
        top_n: int = 5,
        min_similarity_threshold: float = 0.0001
    ) -> Dict[str, Any]:
        """
        Processes a natural language query and recommends the top-N most relevant books.
        
        Handles edge cases:
        - Empty query
        - Stop-words only
        - Out-of-vocabulary queries
        - Zero similarity
        
        Returns:
            Dictionary with:
            - status: "success", "empty_query", "no_matches", "stopwords_only"
            - message: descriptive status message
            - query_details: preprocessing breakdown
            - recommendations: list of matched books with scores
        """
        # Edge Case 1: Empty or whitespace query
        if not query or not query.strip():
            return {
                "status": "empty_query",
                "message": "Please enter a search query.",
                "query_details": {},
                "recommendations": []
            }

        # Analyze query steps
        query_steps = preprocess_with_steps(query)
        processed_query = query_steps["final_processed_text"]

        # Edge Case 2: Query containing only stop words
        if not processed_query.strip():
            return {
                "status": "stopwords_only",
                "message": (
                    "Your query contained only common stop words or conversational phrases. "
                    "Please include specific book subjects, authors, or topics."
                ),
                "query_details": query_steps,
                "recommendations": []
            }

        # Vectorize query
        query_vector = self.vectorizer.transform([query])[0]

        # Edge Case 3: All query terms are out of vocabulary
        if not query_vector:
            return {
                "status": "no_matches",
                "message": (
                    "No relevant matches found in the library catalog for the given terms. "
                    "Try using different or broader keywords."
                ),
                "query_details": query_steps,
                "recommendations": []
            }

        # Compute cosine similarity with every book in dataset
        scored_books: List[Tuple[Dict[str, Any], float]] = []
        for idx, book in enumerate(self.books):
            book_vec = self.book_vectors[idx]
            sim_score = compute_cosine_similarity(query_vector, book_vec)
            if sim_score > min_similarity_threshold:
                scored_books.append((book, sim_score))

        # Rank descending by cosine similarity score
        scored_books.sort(key=lambda x: x[1], reverse=True)

        # Select Top-N
        top_results = []
        for book, score in scored_books[:top_n]:
            top_results.append({
                "book_id": book["book_id"],
                "title": book["title"],
                "author": book["author"],
                "genre": book["genre"],
                "description": book["description"],
                "isbn": book["isbn"],
                "publication_year": book["publication_year"],
                "similarity_score": score
            })

        if not top_results:
            return {
                "status": "no_matches",
                "message": "No books in the library met the relevance threshold for this query.",
                "query_details": query_steps,
                "recommendations": []
            }

        return {
            "status": "success",
            "message": f"Successfully retrieved top {len(top_results)} relevant books.",
            "query_details": {
                "original": query,
                "tokens": query_steps["tokens"],
                "stemmed": query_steps["stemmed_tokens"],
                "active_features": list(query_vector.keys())
            },
            "recommendations": top_results
        }
