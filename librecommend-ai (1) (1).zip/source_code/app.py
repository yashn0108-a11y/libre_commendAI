"""
Streamlit Web Application for AI-Based Smart Library Recommendation System
Course: V Semester ETC - Natural Language Processing (ET5M004)

Run locally using:
    streamlit run source_code/app.py
"""

import os
import sys

# Ensure parent directory is accessible for imports
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

try:
    import streamlit as st
except ImportError:
    print("Streamlit is not installed in the current Python environment.")
    print("Please install requirements using: pip install -r requirements.txt")
    print("Then launch via: streamlit run source_code/app.py")
    sys.exit(1)

from source_code.data_loader import load_books_dataset, get_dataset_summary
from source_code.recommendation import LibraryRecommender
from source_code.preprocessing import preprocess_with_steps


# Streamlit Page Configuration
st.set_page_config(
    page_title="AI-Based Smart Library Recommendation System",
    page_icon="📚",
    layout="wide"
)

# Cache dataset loading and recommender initialization for performance
@st.cache_resource
def get_recommender():
    books = load_books_dataset()
    recommender = LibraryRecommender(books)
    summary = get_dataset_summary(books)
    return recommender, summary


def main():
    # Header Section
    st.title("📚 AI-Based Smart Library Recommendation System")
    st.markdown(
        "**V Semester ETC — Natural Language Processing (ET5M004)**  \n"
        "*Content-Based Recommendation Engine using NLP Preprocessing, TF-IDF Vectorization, and Cosine Similarity.*"
    )

    # Student metadata banner
    with st.expander("👤 Student & Academic Project Details", expanded=False):
        col_meta1, col_meta2, col_meta3 = st.columns(3)
        with col_meta1:
            st.markdown("**Subject:** Natural Language Processing (ET5M004)")
            st.markdown("**Semester:** V Semester B.Tech (ETC)")
        with col_meta2:
            st.markdown("**Student Name:** Yash N")
            st.markdown("**Roll No.:** ET5M004-NLP-2026")
        with col_meta3:
            st.markdown("**Repository:** AI-Smart-Library-Recommendation")
            st.markdown("**Core NLP:** TF-IDF + Cosine Similarity")

    # Load Recommender
    recommender, summary = get_recommender()

    # Sidebar: System Controls & Dataset Overview
    with st.sidebar:
        st.header("⚙️ System Controls")
        top_n = st.slider(
            "Number of recommendations (Top-N):",
            min_value=1,
            max_value=10,
            value=5,
            step=1
        )

        st.divider()
        st.subheader("📊 Library Catalog Overview")
        st.metric("Total Books", summary["total_books"])
        st.metric("Unique Genres", summary["unique_genres"])
        st.metric("Vocabulary Terms", len(recommender.vectorizer.vocabulary))

        st.markdown("**Available Genres:**")
        st.write(", ".join(summary["genres_list"][:8]) + "...")

        st.divider()
        st.subheader("💡 Example Queries")
        example_queries = [
            "I want to learn Python programming for beginners.",
            "Recommend books about artificial intelligence and machine learning.",
            "I am interested in database management systems.",
            "I want a book about communication skills.",
            "Recommend something about robotics and automation.",
            "I want to learn electronics and embedded systems.",
            "Suggest books related to data science."
        ]
        selected_example = st.selectbox("Choose a sample query:", ["-- Custom Input --"] + example_queries)

    # Query Input Section
    st.subheader("🔍 What are you looking for?")

    initial_text = selected_example if selected_example != "-- Custom Input --" else ""
    user_query = st.text_area(
        "Enter your book preference or learning topic in natural language:",
        value=initial_text,
        placeholder="e.g., I want to learn machine learning and neural networks from scratch",
        height=90
    )

    col_btn1, col_btn2 = st.columns([1, 5])
    with col_btn1:
        recommend_clicked = st.button("🚀 Recommend Books", type="primary", use_container_width=True)

    # Recommendation Execution
    if recommend_clicked or (selected_example != "-- Custom Input --" and user_query):
        if not user_query.strip():
            st.warning("⚠️ Please enter a search query.")
            return

        with st.spinner("Processing natural language query and computing similarity scores..."):
            result = recommender.recommend(user_query, top_n=top_n)

        # Handle Responses
        if result["status"] == "empty_query":
            st.warning("⚠️ " + result["message"])
        elif result["status"] == "stopwords_only":
            st.info("ℹ️ " + result["message"])
        elif result["status"] == "no_matches":
            st.warning("🔍 " + result["message"])
        elif result["status"] == "success":
            st.success(f"✨ Found {len(result['recommendations'])} matching books!")

            # Display Recommended Books
            st.subheader("📖 Top Recommended Books")
            for rank, book in enumerate(result["recommendations"], start=1):
                with st.container():
                    st.markdown(f"### {rank}. {book['title']}")
                    col_info1, col_info2, col_info3 = st.columns([2, 2, 1])
                    with col_info1:
                        st.markdown(f"**Author:** {book['author']}")
                    with col_info2:
                        st.markdown(f"**Genre/Category:** `{book['genre']}`")
                    with col_info3:
                        st.markdown(f"**Cosine Sim:** `{book['similarity_score']:.4f}`")

                    st.markdown(f"**Description:** {book['description']}")
                    st.caption(f"ISBN: {book['isbn']} | Year: {book['publication_year']}")
                    st.divider()

            # NLP Pipeline Inspection Section
            with st.expander("🔬 NLP Preprocessing & Feature Breakdown", expanded=False):
                steps = preprocess_with_steps(user_query)
                c1, c2 = st.columns(2)
                with c1:
                    st.markdown("**1. Raw Input:**")
                    st.code(steps["original_text"])
                    st.markdown("**2. Lowercased & Punctuation Cleaned:**")
                    st.code(steps["punctuation_removed"])
                    st.markdown("**3. Tokenized List:**")
                    st.write(steps["tokens"])
                with c2:
                    st.markdown("**4. Filtered Stop Words:**")
                    st.write(steps["removed_stopwords"])
                    st.markdown("**5. Stemmed Root Terms (Active Query Features):**")
                    st.write(steps["stemmed_tokens"])
                    st.markdown("**6. Cosine Similarity Formula:**")
                    st.latex(r"\text{Cosine Similarity}(Q, D) = \frac{Q \cdot D}{\|Q\|_2 \times \|D\|_2}")


if __name__ == "__main__":
    main()
