"""
NLP Preprocessing Module for AI-Based Smart Library Recommendation System
Course: V Semester ETC - Natural Language Processing (ET5M004)

This module implements the fundamental NLP preprocessing stages:
1. Lowercasing: Normalizing case sensitivity (e.g., 'Python' -> 'python')
2. Punctuation Removal: Stripping non-alphanumeric symbols and noise
3. Tokenization: Segmenting continuous text into individual word tokens
4. Stop-word Handling: Filtering high-frequency non-informative grammatical words
5. Stemming: Reducing inflected words to root/base stems (e.g., 'programming' -> 'program')
"""

import re
from typing import List, Set, Dict, Any

# Standard English stop words curated for library text retrieval
STOP_WORDS: Set[str] = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and",
    "any", "are", "aren't", "as", "at", "be", "because", "been", "before", "being",
    "below", "between", "both", "but", "by", "can't", "cannot", "could", "couldn't",
    "did", "didn't", "do", "does", "doesn't", "doing", "don't", "down", "during",
    "each", "few", "for", "from", "further", "had", "hadn't", "has", "hasn't",
    "have", "haven't", "having", "he", "he'd", "he'll", "he's", "her", "here",
    "here's", "hers", "herself", "him", "himself", "his", "how", "how's", "i",
    "i'd", "i'll", "i'm", "i've", "if", "in", "into", "is", "isn't", "it",
    "it's", "its", "itself", "let's", "me", "more", "most", "mustn't", "my",
    "myself", "no", "nor", "not", "of", "off", "on", "once", "only", "or",
    "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same",
    "shan't", "she", "she'd", "she'll", "she's", "should", "shouldn't", "so",
    "some", "such", "than", "that", "that's", "the", "their", "theirs", "them",
    "themselves", "then", "there", "there's", "these", "they", "they'd", "they'll",
    "they're", "they've", "this", "those", "through", "to", "too", "under",
    "until", "up", "very", "was", "wasn't", "we", "we'd", "we'll", "we're",
    "we've", "were", "weren't", "what", "what's", "when", "when's", "where",
    "where's", "which", "while", "who", "who's", "whom", "why", "why's", "with",
    "won't", "would", "wouldn't", "you", "you'd", "you'll", "you're", "you've",
    "your", "yours", "yourself", "yourselves", "want", "recommend", "suggest",
    "need", "looking", "interested", "please", "book", "books"
}


def to_lowercase(text: str) -> str:
    """Converts input text to lowercase."""
    if not isinstance(text, str):
        return ""
    return text.lower()


def remove_punctuation(text: str) -> str:
    """Removes punctuation and non-alphanumeric characters, preserving spaces."""
    if not isinstance(text, str):
        return ""
    return re.sub(r"[^\w\s]", " ", text)


def tokenize(text: str) -> List[str]:
    """Splits normalized text into whitespace-delimited word tokens."""
    if not isinstance(text, str):
        return []
    # Tokenize on one or more whitespace characters
    tokens = [token for token in re.split(r"\s+", text) if token]
    return tokens


def remove_stopwords(tokens: List[str]) -> List[str]:
    """Filters out common English stop words."""
    return [token for token in tokens if token not in STOP_WORDS]


def stem_word(word: str) -> str:
    """
    Applies rule-based suffix reduction (Porter-inspired) to obtain base root words.
    Examples: 'programming' -> 'program', 'algorithms' -> 'algorithm'
    """
    if len(word) <= 3:
        return word

    # Common morphological suffixes in English technical literature
    suffixes = [
        ("sses", "ss"),
        ("ies", "y"),
        ("tional", "tion"),
        ("ation", "ate"),
        ("alism", "al"),
        ("iveness", "ive"),
        ("fulness", "ful"),
        ("ousness", "ous"),
        ("izing", "ize"),
        ("ised", "ise"),
        ("ized", "ize"),
        ("ement", ""),
        ("ment", ""),
        ("able", ""),
        ("ible", ""),
        ("ness", ""),
        ("ting", "t"),
        ("ning", "n"),
        ("ling", "l"),
        ("ring", "r"),
        ("ing", ""),
        ("ted", "t"),
        ("ded", "d"),
        ("ied", "y"),
        ("ed", ""),
        ("ers", "er"),
        ("er", ""),
        ("es", "e"),
        ("s", "")
    ]

    for suffix, replacement in suffixes:
        if word.endswith(suffix) and len(word) - len(suffix) >= 3:
            return word[:-len(suffix)] + replacement

    return word


def apply_stemming(tokens: List[str]) -> List[str]:
    """Applies stemming to each token in the token list."""
    return [stem_word(tok) for tok in tokens]


def preprocess_text(
    text: str,
    lowercase: bool = True,
    remove_punct: bool = True,
    filter_stop: bool = True,
    stem: bool = True
) -> str:
    """
    Full end-to-end preprocessing pipeline returning a space-joined normalized string.
    """
    if not text or not isinstance(text, str):
        return ""

    if lowercase:
        text = to_lowercase(text)

    if remove_punct:
        text = remove_punctuation(text)

    tokens = tokenize(text)

    if filter_stop:
        tokens = remove_stopwords(tokens)

    if stem:
        tokens = apply_stemming(tokens)

    return " ".join(tokens)


def preprocess_with_steps(text: str) -> Dict[str, Any]:
    """
    Returns step-by-step diagnostic breakdown for academic viva demonstration.
    """
    original = text or ""
    step1_lower = to_lowercase(original)
    step2_nopunct = remove_punctuation(step1_lower)
    step3_tokens = tokenize(step2_nopunct)
    step4_no_stop = remove_stopwords(step3_tokens)
    step5_stemmed = apply_stemming(step4_no_stop)
    final_processed = " ".join(step5_stemmed)

    removed_stops = [t for t in step3_tokens if t in STOP_WORDS]

    return {
        "original_text": original,
        "lowercased": step1_lower,
        "punctuation_removed": step2_nopunct,
        "tokens": step3_tokens,
        "token_count": len(step3_tokens),
        "removed_stopwords": removed_stops,
        "filtered_tokens": step4_no_stop,
        "stemmed_tokens": step5_stemmed,
        "final_processed_text": final_processed
    }


if __name__ == "__main__":
    sample = "I want to learn Python programming for beginners in Artificial Intelligence!"
    steps = preprocess_with_steps(sample)
    print("NLP Preprocessing Steps:")
    for key, val in steps.items():
        print(f"  {key}: {val}")
