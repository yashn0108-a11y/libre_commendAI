"""
Data Loader Module for AI-Based Smart Library Recommendation System
Course: V Semester ETC - Natural Language Processing (ET5M004)

This module handles:
1. Loading the legitimate books dataset from CSV.
2. Data cleaning (null checks, stripping whitespace, removing corrupt records).
3. Field normalization.
4. Content combination (combining title, author, genre, description into a single feature text).
"""

import os
import csv
from typing import List, Dict, Any, Optional


def get_default_dataset_path() -> str:
    """Returns the absolute or relative path to the books dataset."""
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    primary_path = os.path.join(base_dir, "dataset", "books_dataset.csv")
    if os.path.exists(primary_path):
        return primary_path
    alt_path = os.path.join("dataset", "books_dataset.csv")
    return alt_path


def load_books_dataset(file_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Loads and cleans the book dataset from CSV file.
    
    Args:
        file_path: Optional custom path to books_dataset.csv
        
    Returns:
        List of cleaned book dictionaries containing:
        book_id, title, author, genre, description, isbn, publication_year, combined_text
    """
    if file_path is None:
        file_path = get_default_dataset_path()

    if not os.path.exists(file_path):
        raise FileNotFoundError(
            f"Dataset file not found at: {file_path}. "
            "Please ensure books_dataset.csv exists in the dataset/ directory."
        )

    books = []
    with open(file_path, mode="r", encoding="utf-8", errors="replace") as f:
        reader = csv.DictReader(f)
        for row_idx, row in enumerate(reader, start=1):
            # Extract and sanitize each field
            book_id = row.get("book_id", str(row_idx)).strip()
            title = row.get("title", "").strip()
            author = row.get("author", "").strip()
            genre = row.get("genre", "").strip()
            description = row.get("description", "").strip()
            isbn = row.get("isbn", "N/A").strip()
            pub_year = row.get("publication_year", "").strip()

            # Skip records lacking essential information
            if not title:
                continue

            # Fill missing metadata gracefully
            if not author:
                author = "Unknown Author"
            if not genre:
                genre = "General"
            if not description:
                description = f"{title} by {author}."

            # Construct the combined text representation for NLP feature extraction:
            # Title + Author + Genre + Description
            combined_text = f"{title} {author} {genre} {description}".strip()

            books.append({
                "book_id": book_id,
                "title": title,
                "author": author,
                "genre": genre,
                "description": description,
                "isbn": isbn,
                "publication_year": pub_year,
                "combined_text": combined_text
            })

    return books


def get_dataset_summary(books: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Computes basic statistics about the loaded dataset."""
    genres = set(b["genre"] for b in books)
    authors = set(b["author"] for b in books)
    total_records = len(books)
    avg_desc_len = (
        sum(len(b["description"].split()) for b in books) / total_records
        if total_records > 0 else 0
    )

    return {
        "total_books": total_records,
        "unique_genres": len(genres),
        "genres_list": sorted(list(genres)),
        "unique_authors": len(authors),
        "avg_words_per_description": round(avg_desc_len, 1)
    }


if __name__ == "__main__":
    loaded = load_books_dataset()
    summary = get_dataset_summary(loaded)
    print(f"Successfully loaded {len(loaded)} books.")
    print(f"Dataset Summary: {summary}")
