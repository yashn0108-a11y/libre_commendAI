"""
Evaluation and Pipeline Runner for AI-Based Smart Library Recommendation System
Course: V Semester ETC - Natural Language Processing (ET5M004)

This script:
1. Loads the books dataset
2. Fits the TF-IDF Vectorizer and builds book vectors
3. Runs standard test cases and edge cases
4. Performs quantitative evaluation (Precision@K, Recall@K, Hit Rate@K, MRR)
5. Generates authentic output files in output/ directory
"""

import os
import sys
from typing import List, Dict, Any

# Ensure parent directory is in python path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from source_code.data_loader import load_books_dataset, get_dataset_summary
from source_code.recommendation import LibraryRecommender


def evaluate_recommendation_system(recommender: LibraryRecommender, k: int = 5) -> Dict[str, Any]:
    """
    Evaluates the recommendation system across a set of academic test queries with labeled
    relevant categories.
    
    Metrics:
    - Precision@K: Fraction of top-K recommendations that are relevant
    - Recall@K: Fraction of total relevant items retrieved in top-K
    - Hit Rate@K: Binary indicator (1 if at least one relevant book in top-K, 0 otherwise)
    - Mean Reciprocal Rank (MRR): Reciprocal rank of the first relevant recommendation
    """
    # Ground truth test queries and their expected relevant genres / keywords
    test_benchmarks = [
        {
            "query": "I want to learn Python programming for beginners.",
            "target_genres": {"Computer Science"},
            "target_keywords": {"python", "program", "beginn"}
        },
        {
            "query": "Recommend books about artificial intelligence and machine learning.",
            "target_genres": {"Artificial Intelligence", "Machine Learning"},
            "target_keywords": {"intellig", "learn", "artifici", "neural"}
        },
        {
            "query": "I am interested in database management systems.",
            "target_genres": {"Database Systems"},
            "target_keywords": {"databas", "sql", "system"}
        },
        {
            "query": "I want a book about communication skills.",
            "target_genres": {"Communication Skills"},
            "target_keywords": {"communic", "speak", "convers"}
        },
        {
            "query": "Recommend something about robotics and automation.",
            "target_genres": {"Robotics"},
            "target_keywords": {"robot", "kinemat", "control"}
        },
        {
            "query": "I want to learn electronics and embedded systems.",
            "target_genres": {"Electronics", "Embedded Systems"},
            "target_keywords": {"electron", "circuit", "embed"}
        },
        {
            "query": "Suggest books related to data science.",
            "target_genres": {"Data Science", "Machine Learning"},
            "target_keywords": {"data", "scienc", "analysi", "statist"}
        }
    ]

    total_precision = 0.0
    total_recall = 0.0
    total_hit_rate = 0.0
    total_reciprocal_rank = 0.0
    per_query_results = []

    # Total catalog counts per genre for Recall calculation
    books = recommender.books

    for bench in test_benchmarks:
        q = bench["query"]
        target_genres = bench["target_genres"]
        res = recommender.recommend(q, top_n=k)
        recs = res.get("recommendations", [])

        # Total relevant items in library for this query's target genres
        total_relevant_in_catalog = sum(
            1 for b in books if b["genre"] in target_genres
        )
        if total_relevant_in_catalog == 0:
            total_relevant_in_catalog = 1

        relevant_retrieved = 0
        first_relevant_rank = None

        for rank_idx, rec in enumerate(recs, start=1):
            is_relevant = rec["genre"] in target_genres
            if is_relevant:
                relevant_retrieved += 1
                if first_relevant_rank is None:
                    first_relevant_rank = rank_idx

        # Compute metrics for this query
        precision = relevant_retrieved / k if k > 0 else 0.0
        recall = relevant_retrieved / total_relevant_in_catalog
        hit_rate = 1.0 if relevant_retrieved > 0 else 0.0
        reciprocal_rank = (1.0 / first_relevant_rank) if first_relevant_rank else 0.0

        total_precision += precision
        total_recall += recall
        total_hit_rate += hit_rate
        total_reciprocal_rank += reciprocal_rank

        per_query_results.append({
            "query": q,
            "target_genres": list(target_genres),
            "retrieved_count": len(recs),
            "relevant_retrieved": relevant_retrieved,
            "precision_at_k": round(precision, 4),
            "recall_at_k": round(recall, 4),
            "hit_rate_at_k": hit_rate,
            "first_hit_rank": first_relevant_rank,
            "reciprocal_rank": round(reciprocal_rank, 4),
            "top_book": recs[0]["title"] if recs else "None"
        })

    num_queries = len(test_benchmarks)
    mean_precision = round(total_precision / num_queries, 4)
    mean_recall = round(total_recall / num_queries, 4)
    mean_hit_rate = round(total_hit_rate / num_queries, 4)
    mrr = round(total_reciprocal_rank / num_queries, 4)

    return {
        "k": k,
        "num_test_queries": num_queries,
        "mean_precision_at_k": mean_precision,
        "mean_recall_at_k": mean_recall,
        "mean_hit_rate_at_k": mean_hit_rate,
        "mean_reciprocal_rank_mrr": mrr,
        "query_evaluations": per_query_results
    }


def run_test_pipeline():
    """Runs data loading, test queries, edge cases, and outputs actual evaluation files."""
    print("=" * 70)
    print("AI-Based Smart Library Recommendation System: Pipeline Execution")
    print("=" * 70)

    # 1. Load Dataset
    books = load_books_dataset()
    summary = get_dataset_summary(books)
    print(f"Loaded {len(books)} books across {summary['unique_genres']} genres.")

    # 2. Initialize Recommender
    recommender = LibraryRecommender(books)
    print(f"TF-IDF Vectorizer initialized. Vocabulary size: {len(recommender.vectorizer.vocabulary)} terms.")

    # 3. Create output directory if not exists
    output_dir = os.path.join(parent_dir, "output")
    os.makedirs(output_dir, exist_ok=True)

    # 4. Run Sample Queries
    sample_queries = [
        "I want to learn Python programming for beginners.",
        "Recommend books about artificial intelligence and machine learning.",
        "I am interested in database management systems.",
        "I want a book about communication skills.",
        "Recommend something about robotics and automation.",
        "I want to learn electronics and embedded systems.",
        "Suggest books related to data science."
    ]

    sample_output_path = os.path.join(output_dir, "sample_recommendations.txt")
    with open(sample_output_path, "w", encoding="utf-8") as f:
        f.write("======================================================================\n")
        f.write("AI-BASED SMART LIBRARY RECOMMENDATION SYSTEM - SAMPLE QUERY OUTPUTS\n")
        f.write("Course: V Semester ETC Natural Language Processing (ET5M004)\n")
        f.write(f"Dataset Size: {len(books)} books | Vocabulary Size: {len(recommender.vectorizer.vocabulary)} terms\n")
        f.write("======================================================================\n\n")

        for idx, query in enumerate(sample_queries, start=1):
            res = recommender.recommend(query, top_n=5)
            f.write(f"TEST QUERY #{idx}:\n")
            f.write(f"Query: \"{query}\"\n")
            f.write(f"Status: {res['status']}\n")
            if res.get("query_details"):
                f.write(f"Active NLP Features: {res['query_details'].get('active_features')}\n")
            f.write("Top-5 Recommended Books:\n")
            for rank, book in enumerate(res.get("recommendations", []), start=1):
                f.write(f"  {rank}. Title: {book['title']}\n")
                f.write(f"     Author: {book['author']}\n")
                f.write(f"     Genre/Category: {book['genre']}\n")
                f.write(f"     Similarity Score: {book['similarity_score']:.4f}\n")
                f.write(f"     Description: {book['description']}\n\n")
            f.write("-" * 65 + "\n\n")

    print(f"Generated sample recommendations file at: {sample_output_path}")

    # 5. Run Edge Cases
    edge_cases = [
        ("Empty Query", ""),
        ("Whitespace Only", "     "),
        ("Single Character", "a"),
        ("Stopwords Only", "what is the book for me and you"),
        ("Special Characters", "!@#$%^&*()_+=-<>?"),
        ("Out of Vocabulary", "quantum xylophone astronaut mars"),
        ("Mixed Case", "pYtHoN pRoGrAmMiNg BeGiNnErS")
    ]

    print("\nExecuting Edge Case Verification:")
    for label, eq in edge_cases:
        edge_res = recommender.recommend(eq, top_n=3)
        print(f"  [{label}] Query: '{eq}' -> Status: {edge_res['status']} | Msg: {edge_res['message'][:55]}...")

    # 6. Run Academic Evaluation
    eval_results = evaluate_recommendation_system(recommender, k=5)
    eval_output_path = os.path.join(output_dir, "evaluation_results.txt")

    with open(eval_output_path, "w", encoding="utf-8") as f:
        f.write("======================================================================\n")
        f.write("AI-BASED SMART LIBRARY RECOMMENDATION SYSTEM - EVALUATION REPORT\n")
        f.write("Course: V Semester ETC Natural Language Processing (ET5M004)\n")
        f.write(f"Total Books: {len(books)} | Test Benchmark Queries: {eval_results['num_test_queries']}\n")
        f.write(f"Cutoff (K): {eval_results['k']} recommendations\n")
        f.write("======================================================================\n\n")

        f.write("OVERALL EVALUATION METRICS (K=5):\n")
        f.write(f"  Mean Precision@5:          {eval_results['mean_precision_at_k'] * 100:.2f}%\n")
        f.write(f"  Mean Recall@5:             {eval_results['mean_recall_at_k'] * 100:.2f}%\n")
        f.write(f"  Mean Hit Rate@5:           {eval_results['mean_hit_rate_at_k'] * 100:.2f}%\n")
        f.write(f"  Mean Reciprocal Rank (MRR): {eval_results['mean_reciprocal_rank_mrr']:.4f}\n\n")

        f.write("PER-QUERY BREAKDOWN:\n")
        f.write("-" * 70 + "\n")
        for q_idx, q_eval in enumerate(eval_results["query_evaluations"], start=1):
            f.write(f"Query #{q_idx}: \"{q_eval['query']}\"\n")
            f.write(f"  Target Categories:    {', '.join(q_eval['target_genres'])}\n")
            f.write(f"  Top Book Retrieved:   {q_eval['top_book']}\n")
            f.write(f"  Relevant in Top-5:    {q_eval['relevant_retrieved']} / 5\n")
            f.write(f"  Precision@5:          {q_eval['precision_at_k']:.4f}\n")
            f.write(f"  Recall@5:             {q_eval['recall_at_k']:.4f}\n")
            f.write(f"  Hit Rate@5:           {q_eval['hit_rate_at_k']}\n")
            f.write(f"  First Hit Rank:       {q_eval['first_hit_rank']}\n")
            f.write(f"  Reciprocal Rank:      {q_eval['reciprocal_rank']:.4f}\n\n")

    print(f"Generated academic evaluation file at: {eval_output_path}")
    print(f"Mean Precision@5: {eval_results['mean_precision_at_k']*100:.2f}% | MRR: {eval_results['mean_reciprocal_rank_mrr']:.4f}")
    print("=" * 70)


if __name__ == "__main__":
    run_test_pipeline()
