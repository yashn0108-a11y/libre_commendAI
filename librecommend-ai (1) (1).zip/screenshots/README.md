# Academic Project Evidence and Screenshots Guide
**Course:** V Semester ETC — Natural Language Processing (ET5M004)  
**Project:** AI-Based Smart Library Recommendation System  

This folder contains screenshot evidence demonstrating the live, operational status of the NLP recommendation system and its repository artifacts.

## Screenshot Index

1. **`application.svg` / `application.png`**:
   - Primary user interface displaying the academic course banner, query input card ("What are you looking for?"), Top-N slider ($K=5$), and sample benchmark queries.

2. **`recommendation_result.svg` / `recommendation_result.png`**:
   - Query: *"I want to learn machine learning for beginners"*
   - Output: Top-5 ranked books showing *Artificial Intelligence: A Modern Approach* (Sim: 0.6938), *Introduction to Machine Learning with Python* (Sim: 0.4906), *Pattern Recognition and Machine Learning* (Sim: 0.4412), *Hands-On Machine Learning with Scikit-Learn* (Sim: 0.4125), and *Deep Learning* (Sim: 0.3891).

3. **`sample_query.svg` / `sample_query.png`**:
   - NLP Pipeline Inspector demonstrating lowercasing, punctuation regex removal, token extraction, stop-word elimination (highlighting discarded filler words), and rule-based stemming mapping words to root terms.

4. **`evaluation_output.png`**:
   - Empirical evaluation dashboard illustrating Mean Precision@5 ($71.43\%$), Mean Recall@5 ($67.96\%$), Hit Rate@5 ($100\%$), and Mean Reciprocal Rank ($0.9286$).

5. **`empty_input_handling.png`**:
   - Graceful error handling verifying that empty and stopword-only queries produce informative feedback rather than runtime exceptions.
