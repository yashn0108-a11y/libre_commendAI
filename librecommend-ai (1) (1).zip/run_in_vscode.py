"""
Interactive Console Runner for VS Code
Course: V Semester ETC - Natural Language Processing (ET5M004)
Project: AI-Based Smart Library Recommendation System

How to run in VS Code:
1. Open this project folder in VS Code
2. Open this file (run_in_vscode.py)
3. Click the "Play" (Run Python File) button in top-right, OR run in VS Code terminal:
   python run_in_vscode.py
"""

import os
import sys

# Ensure parent directory is in sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from source_code.data_loader import load_books_dataset
from source_code.recommendation import LibraryRecommender
from source_code.preprocessing import preprocess_with_steps


def print_banner():
    print("=" * 78)
    print("   AI-BASED SMART LIBRARY RECOMMENDATION SYSTEM (V SEM ETC - ET5M004)   ")
    print("         Content-Based IR using TF-IDF & Cosine Similarity              ")
    print("=" * 78)


def main():
    print_banner()

    dataset_path = os.path.join(BASE_DIR, "dataset", "books_dataset.csv")
    if not os.path.exists(dataset_path):
        print(f"[-] Error: Dataset file not found at: {dataset_path}")
        return

    print(f"[*] Loading academic dataset from: {dataset_path}")
    df = load_books_dataset(dataset_path)
    print(f"[+] Loaded {len(df)} books successfully.")

    print("[*] Initializing NLP Preprocessor and fitting TF-IDF Vectorizer...")
    recommender = LibraryRecommender(df)
    vocab_size = len(recommender.vectorizer.vocabulary)
    print(f"[+] Recommender Engine ready! Vocabulary size: {vocab_size} stemmed features.")
    print("-" * 78)

    # Preset academic demo queries
    preset_queries = [
        "I want to learn Python programming for beginners.",
        "Recommend books about artificial intelligence and machine learning.",
        "I am interested in database management systems.",
        "I want a book about communication skills.",
        "Recommend something about robotics and automation.",
        "I want to learn electronics and embedded systems.",
        "Suggest books related to data science."
    ]

    print("\nQuick Commands:")
    print("  - Type any book preference or learning topic in plain English")
    print("  - Type 'demo' to run the standard academic benchmark queries")
    print("  - Type 'pipeline <query>' to view the step-by-step NLP token inspector")
    print("  - Type 'exit' or 'quit' to close the program\n")

    # If running non-interactively (e.g. piped or automated test), run a demo query and exit
    if not sys.stdin.isatty():
        sample_query = "I want to learn machine learning for beginners."
        print(f"[*] Running automated sample query: '{sample_query}'\n")
        run_query_flow(recommender, sample_query, top_n=5)
        return

    while True:
        try:
            user_input = input("\nEnter search query (or 'exit'): ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting. Thank you!")
            break

        if not user_input:
            print("[!] Please enter a valid non-empty query.")
            continue

        if user_input.lower() in ("exit", "quit", "q"):
            print("Exiting recommendation system. Goodbye!")
            break

        if user_input.lower() == "demo":
            print("\n--- Running Academic Benchmark Demos ---")
            for i, q in enumerate(preset_queries, 1):
                print(f"\n[{i}/{len(preset_queries)}] Benchmark Query: \"{q}\"")
                results = recommender.recommend(q, top_n=3)
                if results["status"] == "success":
                    for rank_i, r in enumerate(results["recommendations"], 1):
                        print(f"   • #{rank_i} [{r['similarity_score']:.4f}] {r['title']} ({r['genre']})")
                else:
                    print(f"   [!] {results['message']}")
            continue

        if user_input.lower().startswith("pipeline "):
            query_to_inspect = user_input[9:].strip()
            inspect_pipeline(query_to_inspect)
            continue

        # Normal query execution
        run_query_flow(recommender, user_input, top_n=5)


def inspect_pipeline(query: str):
    print("\n" + "=" * 60)
    print("          NLP PREPROCESSING PIPELINE BREAKDOWN")
    print("=" * 60)
    steps = preprocess_text_with_steps(query)
    print(f"1. Original Text:       \"{steps['original_text']}\"")
    print(f"2. Lowercase & Regex:   \"{steps['punctuation_removed']}\"")
    print(f"3. Raw Tokens ({steps['token_count']}):      {steps['tokens']}")
    print(f"4. Discarded Stopwords: {steps['removed_stopwords']}")
    print(f"5. Retained Tokens:     {steps['filtered_tokens']}")
    print(f"6. Stemmed Features:    {steps['stemmed_tokens']}")
    print(f"7. Final Query String:  \"{steps['final_processed_text']}\"")
    print("=" * 60)


def run_query_flow(recommender: LibraryRecommender, query: str, top_n: int = 5):
    results = recommender.recommend(query, top_n=top_n)
    status = results["status"]

    if status != "success":
        print(f"\n[!] Status: {status.upper()}")
        print(f"    Message: {results['message']}")
        return

    print(f"\n[+] Status: SUCCESS - Top {len(results['recommendations'])} Recommendations")
    active_feats = results.get("query_details", {}).get("active_features", [])
    if active_feats:
        print(f"    Active vocabulary features: {', '.join(active_feats)}")
    print("-" * 78)

    for rank, rec in enumerate(results["recommendations"], 1):
        pct = rec["similarity_score"] * 100
        print(f"Rank #{rank} | Score: {rec['similarity_score']:.4f} ({pct:.1f}%)")
        print(f"Title:       {rec['title']}")
        print(f"Author:      {rec['author']}")
        print(f"Genre:       {rec['genre']} | Year: {rec['publication_year']} | ISBN: {rec['isbn']}")
        print(f"Description: {rec['description']}")
        print("-" * 78)


if __name__ == "__main__":
    main()
