# AI-Based Smart Library Recommendation System

**Course:** Natural Language Processing (ET5M004)  
**Academic Level:** V Semester B.Tech, Electronics and Telecommunication Engineering (ETC)  
**Activity:** Creating GitHub Repositories for NLP Applications  

---

## 1. Project Title
**AI-Based Smart Library Recommendation System**

## 2. Student Name
**Yash N**

## 3. Roll Number
**ET5M004-NLP-2026**

## 4. GitHub Repository
**`AI-Smart-Library-Recommendation`**

---

## 5. Problem Statement
Academic library catalogs often house thousands of textbooks and research volumes across engineering, sciences, and humanities. Conventional Online Public Access Catalogs (OPAC) rely predominantly on exact keyword matching, specific title lookups, or explicit author searches. When students enter natural-language, intent-driven queries—such as *"I want to learn machine learning for beginners"* or *"suggest books related to data science"*—traditional Boolean search engines either fail to return relevant materials or retrieve an overwhelming number of irrelevant hits due to morphological variation and phrasing differences.

## 6. Objective
The primary objective of this project is to develop an AI-based, lightweight, and explainable **Smart Library Recommendation System** using Natural Language Processing techniques. The system accepts natural language user search queries, preprocesses text using linguistic normalization rules, transforms book metadata into a mathematical vector space using **TF-IDF (Term Frequency-Inverse Document Frequency)**, and retrieves the most conceptually relevant books using **Cosine Similarity Ranking**.

---

## 7. Introduction
With the exponential expansion of digital and physical university libraries, content discoverability is crucial for students and researchers. An AI-based recommendation system bridges the semantic gap between how students naturally ask for study material and how books are indexed in library catalogs. By analyzing book titles, authors, categories, and technical descriptions, our NLP engine delivers ranked, contextually relevant reading suggestions.

## 8. Background of Library Recommendation Systems
Early automated library systems in the 1970s and 1980s used the Dewey Decimal or Library of Congress classification systems alongside inverted index keyword lookups. In the 1990s and 2000s, collaborative filtering emerged in commercial settings (such as Amazon and Netflix), relying on user transaction history and rating matrices. However, academic libraries suffer from the **cold-start problem** (new books have no borrow history) and **data sparsity** (students borrow only a few books per semester). Consequently, **Content-Based Information Retrieval (CBIR)** using NLP represents the most reliable, privacy-preserving, and computationally feasible foundation for academic library recommendation.

## 9. Role of Artificial Intelligence
Artificial Intelligence allows computational systems to extract abstract information from unstructured text, learn statistical distributions of language features, and make intelligent inferences without explicit hardcoded rules. In this project, AI provides:
- Automated feature representation through text vectorization.
- Geometric distance evaluation on high-dimensional document manifolds.
- Relevance ranking to emulate the assistance of an experienced university reference librarian.

## 10. Role of Natural Language Processing (NLP)
NLP converts unstructured natural-language strings into structured, machine-interpretable numeric vectors. Key roles played by NLP in this system include:
- Removing syntactic noise (punctuation, capitalization discrepancies).
- Stripping high-frequency, non-discriminative stop words.
- Morphological stemming to map grammatical variations to shared conceptual roots.
- Building vocabulary feature spaces that capture term importance.

---

## 11. Recommendation System Concepts
Recommendation systems are classified into three primary paradigms:
1. **Content-Based Filtering:** Recommends items based on the features and metadata of the items themselves compared to a query or user profile. *(Used in this project)*
2. **Collaborative Filtering:** Recommends items based on the behavioral history (ratings, clicks, borrows) of similar users.
3. **Hybrid Systems:** Combines content attributes with collaborative interaction history.

This project implements a pure **Content-Based Recommendation Engine** using Information Retrieval vector space modeling.

## 12. NLP Techniques Used
- **Case Normalization (Lowercasing)**
- **Punctuation Stripping & Regex Sanitization**
- **Whitespace Tokenization**
- **Domain-Specific Stop-Word Filtering**
- **Rule-Based Morphological Stemming (Porter-style)**
- **Term Frequency - Inverse Document Frequency (TF-IDF) Representation**
- **Euclidean ($L_2$) Vector Normalization**
- **Cosine Similarity Dot-Product Scoring**

---

## 13. Dataset and Source
- **Dataset Name:** Curated Academic & Engineering Library Catalog Dataset
- **Primary Sources:** Open Library (Internet Archive - `https://openlibrary.org/`) and Project Gutenberg catalog metadata.
- **License / Usage:** Open Data Commons Open Database License (ODbL) / Public Domain metadata.
- **Date of Access:** September 2026.
- **File Location:** `dataset/books_dataset.csv`.

## 14. Dataset Description
The dataset contains **60 legitimate, published textbooks and references** commonly used in computer science, electronics, mathematics, and communication engineering curricula:
- **`book_id`**: Unique integer identifier.
- **`title`**: Full canonical book title.
- **`author`**: Primary author(s) or editor(s).
- **`genre`**: Departmental discipline/subject category (e.g., *Computer Science*, *Machine Learning*, *Database Systems*, *Electronics*, *Robotics*).
- **`description`**: Comprehensive summary of textbook topics, coverage, and prerequisites.
- **`isbn`**: Legitimate 13-digit International Standard Book Number.
- **`publication_year`**: Original or widely referenced publication edition year.

## 15. Dataset Preprocessing
Data cleaning procedures implemented in `source_code/data_loader.py`:
1. **Missing-Value Imputation:** Empty authors default to `"Unknown Author"`, empty genres to `"General"`, and descriptions to title and author combinations.
2. **Whitespace Stripping:** Removal of leading/trailing spaces and carriage returns.
3. **Content Synthesis:** A unified document feature string is synthesized for each record:
   $$\text{Combined Content} = \text{Title} + \text{Author} + \text{Genre} + \text{Description}$$

---

## 16. Software, Tools, and Libraries
- **Language:** Python 3.10+
- **Core Standard Libraries:** `re`, `math`, `csv`, `collections`, `json`, `os`, `sys`
- **Machine Learning & NLP Frameworks:** `scikit-learn`, `nltk`, `pandas`, `numpy`
- **Web UI Engine:** `Streamlit` (Python web application) + Vite/React preview
- **Version Control:** Git & GitHub

## 17. System Requirements
- **Hardware:**
  - CPU: Dual-Core 1.8 GHz or faster
  - RAM: 2 GB minimum (Lightweight memory footprint < 100 MB)
  - Storage: 150 MB free disk space
- **Operating System:** Linux, macOS, or Windows 10/11
- **Software:** Python 3.8 or higher, modern web browser (Chrome, Firefox, Safari, Edge)

---

## 18. Project Architecture
```
User (Browser / Streamlit UI)
            │
            ▼ (Natural Language Query)
┌───────────────────────────────────────────────┐
│              NLP Preprocessing Pipeline       │
│  - Lowercasing                                │
│  - Punctuation Removal                        │
│  - Tokenization                               │
│  - Stop-Word Filtering                        │
│  - Stemming                                   │
└───────────────────────────────────────────────┘
            │
            ▼ (Normalized Query Tokens)
┌───────────────────────────────────────────────┐
│             TF-IDF Vector Space Model         │
│  - Document Vocabulary (710 Terms)            │
│  - Inverse Document Frequency (IDF) Weights   │
│  - Query Vector Transformation                │
│  - L2-Norm Unit Sphere Normalization          │
└───────────────────────────────────────────────┘
            │
            ▼ (Sparse Normalized Vector Q)
┌───────────────────────────────────────────────┐
│        Cosine Similarity Engine               │
│  - Dot product: Sim(Q, D_i) = Q · D_i         │
│  - Dynamic Relevance Scoring (0.0 to 1.0)     │
│  - Descending Rank Sort                       │
└───────────────────────────────────────────────┘
            │
            ▼
┌───────────────────────────────────────────────┐
│           Top-N Recommendation Output         │
│  - Book Title, Author, Genre, Description     │
│  - Computed Similarity Score                  │
└───────────────────────────────────────────────┘
```

## 19. Methodology and Workflow
1. **Catalog Preparation:** Load CSV catalog, clean missing fields, and concatenate metadata into feature strings.
2. **Vocabulary Building:** Scan all book feature strings, tokenize, strip stop words, stem words, and build a unique 710-term vocabulary.
3. **IDF Matrix Computation:** Calculate global inverse document frequencies for all vocabulary tokens.
4. **Book Vectorization:** Transform each book into an $L_2$-normalized TF-IDF vector.
5. **Runtime Query Handling:** Preprocess the user's natural-language query through identical NLP filters.
6. **Similarity Matching:** Compute the cosine angle between the query vector and every book in the library catalog.
7. **Ranking & Display:** Sort books by descending score, prune non-matches, and display the top $N$ recommendations.

---

## 20. Text Preprocessing Details
1. **Lowercasing:** Converts all text to lowercase (e.g., `"Machine Learning"` $\rightarrow$ `"machine learning"`) to avoid case-sensitive duplicate tokens.
2. **Punctuation Removal:** Uses regular expression `re.sub(r"[^\w\s]", " ", text)` to replace special symbols, colons, hyphens, and quotes with whitespace.
3. **Tokenization:** Breaks the normalized string into individual token lists using whitespace boundaries.
4. **Stop-word Handling:** Filters out common English grammatical words (*"in"*, *"the"*, *"with"*, *"about"*) and conversational query filler (*"recommend"*, *"looking"*, *"want"*, *"book"*).
5. **Stemming:** Applies rule-based suffix reduction to collapse word variants (e.g., `"programming"` $\rightarrow$ `"program"`, `"algorithms"` $\rightarrow$ `"algorithm"`).

---

## 21. Feature Extraction
Feature extraction transforms text strings into numerical vectors amenable to algebraic comparison. In this project, each book is represented as a point in a 710-dimensional sparse vocabulary space.

## 22. TF-IDF Explanation
**Term Frequency (TF):** Evaluates how often term $t$ occurs in a document $d$:
$$\text{TF}(t, d) = \frac{f_{t,d}}{\sum_{t'} f_{t',d}}$$

**Inverse Document Frequency (IDF):** Penalizes generic terms present in nearly every document in the library:
$$\text{IDF}(t) = \ln\left(\frac{1 + N}{1 + \text{DF}(t)}\right) + 1$$
where $N$ is the total number of books in the catalog (60), and $\text{DF}(t)$ is the number of books containing term $t$.

**TF-IDF:**
$$\text{TF-IDF}(t, d) = \text{TF}(t, d) \times \text{IDF}(t)$$

Vectors are then normalized using the Euclidean norm:
$$\hat{v} = \frac{v}{\|v\|_2} = \frac{v}{\sqrt{\sum v_i^2}}$$

## 23. Cosine Similarity Explanation
Cosine Similarity measures the cosine of the angle $\theta$ between the user's query vector $Q$ and a candidate book vector $D$:
$$\text{Cosine Similarity}(Q, D) = \frac{Q \cdot D}{\|Q\|_2 \times \|D\|_2} = \frac{\sum_{i=1}^M Q_i D_i}{\sqrt{\sum_{i=1}^M Q_i^2} \sqrt{\sum_{i=1}^M D_i^2}}$$

Because both $Q$ and $D$ are pre-normalized to unit length ($\|Q\|_2 = 1$, $\|D\|_2 = 1$), the cosine similarity simplifies to the efficient dot product:
$$\text{Cosine Similarity}(Q, D) = \sum_{i=1}^M Q_i D_i$$
Scores range from $0.0$ (no shared vocabulary terms) to $1.0$ (identical vocabulary distributions).

## 24. Recommendation Algorithm
```python
def recommend(query, top_n=5):
    if not query.strip():
        return "Please enter a search query."
    query_vector = vectorizer.transform([query])
    if not query_vector:
        return "No relevant matches found."
    scores = []
    for book, book_vector in zip(books, book_vectors):
        sim = compute_cosine_similarity(query_vector, book_vector)
        if sim > 0:
            scores.append((book, sim))
    scores.sort(key=lambda x: x[1], reverse=True)
    return scores[:top_n]
```

## 25. Processing and Training Procedure
Because TF-IDF and Cosine Similarity are unsupervised information retrieval techniques, **conventional gradient-based training or backpropagation is not required**. The "training" phase consists of computing the term document matrix and global IDF lookups over the catalog.

---

## 26. Testing Procedure
The recommendation pipeline was tested against diverse query categories:
1. **Realistic Subject Queries:** Programming, AI, Databases, Soft Skills, Embedded Systems, Data Science.
2. **Edge Cases:**
   - Empty input (`""`) $\rightarrow$ Returns clear validation warning.
   - Whitespace only (`"   "`) $\rightarrow$ Handled without failure.
   - Stop words only (`"what is the book for me and you"`) $\rightarrow$ Detects stop-word-only input and advises adding domain keywords.
   - Special characters (`"!@#$%^&*()"`) $\rightarrow$ Sanitized without crash.
   - Out-of-vocabulary terms (`"quantum xylophone astronaut mars"`) $\rightarrow$ Reports no catalog match.
   - Mixed-case variations (`"pYtHoN pRoGrAmMiNg"`) $\rightarrow$ Properly normalized and matched.

---

## 27. Evaluation Methodology
The system was evaluated on a benchmark of 7 labeled academic test queries with $K=5$:
- **Precision@K:** Proportion of top-$K$ recommendations matching target disciplines:
  $$\text{Precision@K} = \frac{|\text{Relevant Books in Top-K}|}{K}$$
- **Recall@K:** Proportion of total catalog books for that topic retrieved in top-$K$:
  $$\text{Recall@K} = \frac{|\text{Relevant Books in Top-K}|}{|\text{Total Relevant Books in Catalog}|}$$
- **Hit Rate@K:** Binary indicator: $1$ if at least one relevant book is present in the top-$K$, $0$ otherwise.
- **Mean Reciprocal Rank (MRR):** Evaluates where the first relevant book appears:
  $$\text{MRR} = \frac{1}{|Q|} \sum_{i=1}^{|Q|} \frac{1}{\text{rank}_i}$$

## 28. Results and Observations
Actual calculated results from `output/evaluation_results.txt`:
- **Total Catalog Size:** 60 books
- **Vocabulary Size:** 710 unique stemmed tokens
- **Mean Precision@5:** **71.43%**
- **Mean Recall@5:** **67.96%**
- **Mean Hit Rate@5:** **100.00%**
- **Mean Reciprocal Rank (MRR):** **0.9286**

**Key Observations:**
1. Queries targeting distinct domains (e.g., *"artificial intelligence and machine learning"*) achieved **100% Precision@5** and a rank-1 first hit.
2. The system successfully handles natural queries containing conversational phrases like *"I want to learn..."* because conversational tokens are safely filtered out by the stop-word handler.
3. Ranking by cosine angle accurately separates introductory titles from specialized volumes.

---

## 29. Folder Structure
```
AI-Smart-Library-Recommendation/
│
├── README.md                                # Comprehensive academic documentation (37 sections)
├── VIVA_PREPARATION.md                      # Viva questions, answers, and 2-min pitch
├── requirements.txt                         # Python dependencies
├── .gitignore                               # Standard git ignore rules
│
├── dataset/
│   └── books_dataset.csv                    # Legitimate 60-book library catalog dataset
│
├── source_code/
│   ├── __init__.py                          # Python package initialization
│   ├── data_loader.py                       # Data loading, validation, and content combination
│   ├── preprocessing.py                     # NLP lowercasing, punctuation, tokens, stop-words, stemming
│   ├── recommendation.py                    # TF-IDF vectorizer, cosine similarity, and recommender
│   ├── train_model.py                       # Automated test pipeline and evaluation runner
│   └── app.py                              # Streamlit interactive web application
│
├── notebooks/
│   └── smart_library_recommendation.ipynb   # Complete step-by-step Jupyter notebook
│
├── output/
│   ├── sample_recommendations.txt           # Actual outputs generated by sample queries
│   └── evaluation_results.txt               # Computed Precision@K, Recall@K, Hit Rate@K, MRR
│
└── screenshots/
    ├── application.png                      # Application dashboard screenshot
    ├── recommendation_result.png            # Recommendation list screenshot
    └── sample_query.png                     # Example query inspection screenshot
```

---

## 30. Installation Instructions
1. Clone or download the repository:
   ```bash
   git clone https://github.com/yashn0108/AI-Smart-Library-Recommendation.git
   cd AI-Smart-Library-Recommendation
   ```
2. (Recommended) Create and activate a Python virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## 31. Execution Steps
### Run the Streamlit Web Application:
```bash
streamlit run source_code/app.py
```
Open `http://localhost:8501` in your browser.

### Run Automated Evaluation & Generate Output Files:
```bash
python3 source_code/train_model.py
```

### Run Jupyter Notebook:
```bash
jupyter notebook notebooks/smart_library_recommendation.ipynb
```

---

## 32. Sample Queries
1. *"I want to learn Python programming for beginners."*
2. *"Recommend books about artificial intelligence and machine learning."*
3. *"I am interested in database management systems."*
4. *"I want a book about communication skills."*
5. *"Recommend something about robotics and automation."*
6. *"I want to learn electronics and embedded systems."*
7. *"Suggest books related to data science."*

## 33. Sample Outputs
**Query:** *"I want to learn Python programming for beginners."*
- **Active Filtered Features:** `['learn', 'python', 'programm', 'beginner']`
- **Top Recommended Book:** *Python Crash Course* by Eric Matthes (Cosine Sim: `0.3511`)
- **Rank 2:** *Introduction to Machine Learning with Python* by Andreas C. Müller (Cosine Sim: `0.3197`)
- **Rank 3:** *Learning Python* by Mark Lutz (Cosine Sim: `0.2987`)
- **Rank 4:** *Automate the Boring Stuff with Python* by Al Sweigart (Cosine Sim: `0.2913`)

---

## 34. Limitations
1. **Lexical Matching Limitation:** TF-IDF relies on token overlap; it cannot detect synonyms without shared roots (e.g., *"physician"* vs. *"doctor"*).
2. **Word Order Invariance:** TF-IDF ignores syntactic word order (Bag-of-Words assumption).
3. **Out-of-Vocabulary (OOV):** If a user query contains only words not present in the catalog vocabulary, the similarity score is zero.
4. **Cold Catalog Scale:** With 60 books, niche subtopics may have limited representation.

## 35. Future Scope
1. **Dense Semantic Embeddings:** Implementing Transformer models (e.g., Sentence-BERT / `all-MiniLM-L6-v2`) for conceptual and contextual similarity.
2. **Live Catalog APIs:** Connecting to Google Books or Open Library APIs for real-time live book data.
3. **Collaborative Filtering Hybridization:** Incorporating user borrow history and course syllabus recommendations.
4. **Multilingual NLP:** Adding lemmatization and tokenization for regional and international languages.
5. **Book Cover Retrieval & Visual Display:** Integrating Open Library Book Covers API.

---

## 36. Conclusion
The **AI-Based Smart Library Recommendation System** satisfies all academic requirements for the V Semester Natural Language Processing course. By integrating disciplined NLP preprocessing (lowercasing, punctuation removal, tokenization, stop-word removal, stemming) with TF-IDF vectorization and Cosine Similarity, the system transforms natural language queries into accurate, dynamic book recommendations. Comprehensive testing across standard benchmarks demonstrated high relevance (**MRR of 0.9286** and **Hit Rate@5 of 100%**), while edge-case guards guarantee application stability.

## 37. References
1. Manning, C. D., Raghavan, P., & Schütze, H. (2008). *Introduction to Information Retrieval*. Cambridge University Press.
2. Jurafsky, D., & Martin, J. H. (2023). *Speech and Language Processing* (3rd ed. draft). Pearson.
3. Bird, S., Klein, E., & Loper, E. (2009). *Natural Language Processing with Python*. O'Reilly Media.
4. Open Library Catalog API and Metadata Archives: https://openlibrary.org/
5. Salton, G., & Buckley, C. (1988). Term-weighting approaches in automatic text retrieval. *Information Processing & Management*, 24(5), 513-523.
