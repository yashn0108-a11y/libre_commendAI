# VIVA PREPARATION GUIDE
## AI-Based Smart Library Recommendation System
**Course:** V Semester B.Tech (ETC) — Natural Language Processing (ET5M004)  
**Student Name:** Yash N  
**Roll No:** ET5M004-NLP-2026  
**GitHub Repository:** AI-Smart-Library-Recommendation  

---

## 1. Simple Project Explanation (Layman's Terms)
Our project is a digital smart library assistant. Instead of forcing a user to know the exact title or author of a book, the user can type what they want to study in everyday natural language (e.g., *"I want to learn machine learning for beginners"*). The system uses Natural Language Processing (NLP) to clean the words, convert the concepts into mathematical vectors using TF-IDF, and compare them against book descriptions using Cosine Similarity to recommend the best matching books.

---

## 2. 2-Minute Elevator Pitch / Introduction
> "Good morning, Respected Examiners. I am presenting our V Semester NLP project: **'AI-Based Smart Library Recommendation System'**. In academic libraries, traditional catalog search relies on rigid boolean or exact keyword matching, which fails when students express conceptual needs such as *'I want to learn electronics and embedded systems'*.  
> To address this, we developed a content-based recommendation system that ingests a curated catalog of 60 legitimate technical books. The pipeline applies standard NLP preprocessing: lowercasing, punctuation stripping, tokenization, stop-word removal, and rule-based stemming. We then compute a Term Frequency-Inverse Document Frequency (TF-IDF) feature matrix across a 710-term vocabulary. When a student enters a query, it is transformed into the same vector space, and Cosine Similarity ranks the books by angular proximity. On our benchmark test queries, the system achieved a **Mean Hit Rate@5 of 100%**, a **Mean Precision@5 of 71.4%**, and a **Mean Reciprocal Rank (MRR) of 0.9286**. The solution runs as a lightweight, interactive academic application with real-time NLP inspection."

---

## 3. 5-Minute Deep-Dive Technical Explanation
1. **Data Ingestion & Cleaning:**
   - The catalog comprises 60 legitimate textbooks sourced from Open Library and standard university references.
   - For each book, we synthesize a rich metadata document: $\text{Combined Text} = \text{Title} + \text{Author} + \text{Genre} + \text{Description}$.
2. **Text Preprocessing Pipeline:**
   - **Case Normalization:** Converts strings to lowercase to eliminate typographical discrepancies.
   - **Punctuation Removal:** Uses regular expressions `[^\w\s]` to strip non-alphanumeric noise.
   - **Tokenization:** Breaks the continuous string into discrete word tokens.
   - **Stop-word Filtering:** Removes high-frequency function words (e.g., *"the"*, *"with"*, *"is"*) as well as domain-specific conversational noise (e.g., *"recommend"*, *"want"*, *"book"*).
   - **Stemming:** Applies morphological suffix stripping to reduce grammatical variants (e.g., *"programming"*, *"programmer"*, *"programs"*) down to their common root `program`.
3. **TF-IDF Feature Representation:**
   - **Term Frequency (TF):** Measures how frequently term $t$ appears in document $d$:
     $$\text{TF}(t, d) = \frac{f_{t,d}}{\sum_{t'} f_{t',d}}$$
   - **Inverse Document Frequency (IDF):** Penalizes ubiquitous terms that appear across many books:
     $$\text{IDF}(t) = \ln\left(\frac{1 + N}{1 + \text{DF}(t)}\right) + 1$$
   - **TF-IDF:**
     $$\text{TF-IDF}(t, d) = \text{TF}(t, d) \times \text{IDF}(t)$$
   - Each vector is $L_2$-normalized to a unit hypersphere ($\|v\|_2 = 1$).
4. **Cosine Similarity & Ranking:**
   - The query vector $Q$ and book vector $D$ are compared via the Cosine of their angle $\theta$:
     $$\text{Cosine Similarity}(Q, D) = \frac{Q \cdot D}{\|Q\|_2 \times \|D\|_2} = \sum_{t} Q_t \times D_t$$
   - Similarity scores range from $0.0$ (orthogonal/no overlap) to $1.0$ (identical direction).
   - Books are sorted descending by similarity, and Top-$N$ (default $N=5$) are presented.
5. **Robust Edge Case Handling:**
   - Explicit guards for empty inputs, whitespace-only queries, stopword-only queries, and out-of-vocabulary terms ensure zero runtime crashes.

---

## 4. 20 Crucial Viva Questions and Answers

### NLP Basics
1. **Q: What is NLP and why is it required in this project?**  
   *A:* Natural Language Processing is the branch of AI enabling computers to process, understand, and extract meaning from human language. It is required here because users express book searches in conversational, unstructured text rather than structured database keys.

2. **Q: What is tokenization?**  
   *A:* Tokenization is the process of splitting a continuous sequence of text characters into discrete semantic units called tokens (words, punctuation, or subwords).

3. **Q: Why is stop-word removal important?**  
   *A:* Stop words (such as *"and"*, *"the"*, *"is"*) occur with high frequency across nearly all documents but carry minimal discriminative semantic meaning. Removing them reduces dimensionality and prevents noise from dominating similarity calculations.

4. **Q: What is the difference between stemming and lemmatization?**  
   *A:* Stemming uses heuristic, rule-based suffix chopping (e.g., removing *-ing* or *-ed*) to reach a crude stem, which may not be a valid dictionary word. Lemmatization uses morphological vocabulary analysis and Part-of-Speech (POS) tags to return the true grammatical base form (lemma).

5. **Q: What is text normalization?**  
   *A:* Text normalization transforms text into a canonical, consistent format (e.g., lowercasing, stripping punctuation, converting numbers) so surface-level variations don't prevent term matching.

### TF-IDF
6. **Q: What is Term Frequency (TF)?**  
   *A:* Term Frequency measures how often a specific word appears within a single document relative to the total number of words in that document.

7. **Q: What is Inverse Document Frequency (IDF)?**  
   *A:* IDF measures how rare or informative a word is across the entire corpus. If a word appears in every document, its IDF is low; if it appears in only 1 or 2 books, its IDF is high.

8. **Q: Why is TF-IDF superior to simple Bag-of-Words (raw word counts)?**  
   *A:* Bag-of-Words rewards sheer frequency, meaning words that appear often regardless of importance receive high weights. TF-IDF balances frequency with rarity, boosting unique domain terms while dampening pervasive terms.

9. **Q: What are the primary limitations of TF-IDF?**  
   *A:* TF-IDF relies on lexical (exact token) matching and suffers from the vocabulary mismatch problem. It cannot recognize semantic synonyms (e.g., *"physician"* vs. *"doctor"*) or context without additional n-grams or dense embeddings.

### Cosine Similarity & Vector Space
10. **Q: What is Cosine Similarity and why is it preferred over Euclidean Distance for text?**  
    *A:* Cosine Similarity measures the cosine of the angle between two vectors in multi-dimensional space. It is preferred over Euclidean distance because it evaluates orientation rather than magnitude, meaning a short book description and a long detailed summary discussing the same topic will still achieve high similarity.

11. **Q: What does a Cosine Similarity score of 0, 1, and negative mean in text processing?**  
    *A:* In TF-IDF text vectors (where term weights are non-negative), scores range between $0$ and $1$. A score of $1.0$ indicates identical term distributions; $0.0$ indicates no overlapping vocabulary (orthogonal vectors). Negative scores do not occur because TF and IDF are non-negative.

12. **Q: How does L2 normalization simplify the calculation of Cosine Similarity?**  
    *A:* If both vectors are normalized such that their Euclidean norm $\|v\|_2 = 1$, the denominator $\|Q\|_2 \times \|D\|_2$ equals $1$. Therefore, Cosine Similarity simplifies to the vector dot product.

### Recommendation System
13. **Q: What is a Content-Based Recommendation System?**  
    *A:* A Content-Based recommender suggests items by comparing the descriptive features/attributes of items (e.g., book title, genre, summary) directly to the user's explicit query or historical item preferences.

14. **Q: Is this project a supervised machine learning model?**  
    *A:* No. This is an unsupervised Information Retrieval and Content-Based Similarity method. It does not use labeled training targets, loss functions, or backpropagation; it builds a deterministic vector space representation.

15. **Q: What happens when a user enters words not present in the dataset?**  
    *A:* This is an Out-of-Vocabulary (OOV) situation. The query vector will contain zero non-zero components, leading to a dot product of $0.0$ with all books. The system handles this gracefully by notifying the user that no matching keywords were found in the catalog.

### Dataset & Evaluation
16. **Q: What dataset was used and how was it cleaned?**  
    *A:* We used a curated catalog of 60 legitimate technical and academic books from Open Library and standard engineering curricula. Cleaning steps included stripping extraneous whitespace, handling missing fields, and synthesizing unified metadata text.

17. **Q: What is Precision@K and Recall@K?**  
    *A:*  
    - **Precision@K:** Proportion of the top-$K$ recommended items that are truly relevant:  
      $$\text{Precision@K} = \frac{|\text{Relevant Items in Top-K}|}{K}$$  
    - **Recall@K:** Proportion of all relevant items in the catalog that were successfully retrieved in the top-$K$:  
      $$\text{Recall@K} = \frac{|\text{Relevant Items in Top-K}|}{|\text{Total Relevant in Catalog}|}$$

18. **Q: What is Mean Reciprocal Rank (MRR)?**  
    *A:* MRR evaluates where the first relevant recommendation appears in the ranked list. If the first relevant book is at rank 1, reciprocal rank is $1/1 = 1$; if at rank 2, it is $1/2 = 0.5$. The average across all test queries is the MRR. In our project, the MRR is **0.9286**.

19. **Q: What is Git and why are meaningful commits important?**  
    *A:* Git is a distributed version control system. Meaningful commits provide an atomic, chronological, and reproducible history of development, making code changes auditable and collaborative.

20. **Q: What are the key future enhancements for this system?**  
    *A:* Transitioning from lexical TF-IDF to dense semantic embeddings (e.g., `all-MiniLM-L6-v2` via Sentence-Transformers), incorporating real-time live APIs (Open Library/Google Books), and introducing collaborative filtering based on student loan histories.
