import React from 'react';
import { BookOpen, Sparkles, Database, BarChart3, HelpCircle, GitBranch, GraduationCap } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  totalBooks: number;
  vocabSize: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  totalBooks,
  vocabSize
}) => {
  const navItems = [
    { id: 'recommend', label: 'Recommendation System', icon: Sparkles },
    { id: 'pipeline', label: 'NLP Pipeline Inspector', icon: BookOpen },
    { id: 'catalog', label: `Library Catalog (${totalBooks})`, icon: Database },
    { id: 'evaluation', label: 'Evaluation & Metrics', icon: BarChart3 },
    { id: 'viva', label: 'Viva Prep & Architecture', icon: HelpCircle }
  ];

  return (
    <header className="border-b border-stone-200 bg-white/95 backdrop-blur-sm sticky top-0 z-50">
      {/* Top Academic Course Bar */}
      <div className="bg-stone-900 text-stone-200 px-4 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-semibold text-white">V Semester B.Tech (ETC)</span>
            <span className="text-stone-500">•</span>
            <span>Natural Language Processing (ET5M004)</span>
            <span className="text-stone-500">•</span>
            <span className="bg-stone-800 px-2 py-0.5 rounded text-stone-300 font-mono text-[11px]">Academic Activity</span>
          </div>
          <div className="flex items-center gap-3 text-stone-400">
            <span>Student: <strong className="text-white">Yash N</strong></span>
            <span>Roll No: <strong className="text-white">ET5M004-NLP-2026</strong></span>
            <div className="flex items-center gap-1 text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-800/40">
              <GitBranch className="w-3 h-3" />
              <span className="font-mono text-[11px]">AI-Smart-Library-Recommendation</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Title Bar */}
      <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-sm shadow-emerald-500/20">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-stone-900 tracking-tight">
                AI-Based Smart Library Recommendation System
              </h1>
              <p className="text-xs text-stone-600">
                Content-Based Information Retrieval using TF-IDF Vectorization & Cosine Similarity
              </p>
            </div>
          </div>
        </div>

        {/* Live Corpus Stats */}
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block border-r border-stone-200 pr-3">
            <div className="text-[11px] uppercase tracking-wider text-stone-500 font-medium">Dataset Status</div>
            <div className="text-xs font-semibold text-stone-800">{totalBooks} Academic Books Verified</div>
          </div>
          <div className="text-right hidden sm:block">
            <div className="text-[11px] uppercase tracking-wider text-stone-500 font-medium">Vocabulary</div>
            <div className="text-xs font-semibold text-emerald-700 font-mono">{vocabSize} Stemmed Terms</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 flex gap-1 overflow-x-auto border-t border-stone-100">
        {navItems.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`nav-tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-medium whitespace-nowrap transition-colors border-b-2 -mb-px ${
                isActive
                  ? 'border-emerald-600 text-emerald-700 bg-emerald-50/40 font-semibold'
                  : 'border-transparent text-stone-600 hover:text-stone-900 hover:border-stone-300'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-600' : 'text-stone-400'}`} />
              {tab.label}
            </button>
          );
        })}
      </div>
    </header>
  );
};
