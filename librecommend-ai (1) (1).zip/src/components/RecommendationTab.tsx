import React, { useState } from 'react';
import { Sparkles, ArrowRight, AlertCircle, CheckCircle2, Sliders, Layers, Search, RefreshCw } from 'lucide-react';
import { QueryResponse } from '../types';

interface RecommendationTabProps {
  onRunQuery: (query: string, topN: number) => QueryResponse;
  currentResponse: QueryResponse | null;
  currentQuery: string;
  setCurrentQuery: (q: string) => void;
  topN: number;
  setTopN: (n: number) => void;
  onInspectPipeline: () => void;
}

export const RecommendationTab: React.FC<RecommendationTabProps> = ({
  onRunQuery,
  currentResponse,
  currentQuery,
  setCurrentQuery,
  topN,
  setTopN,
  onInspectPipeline
}) => {
  const [isProcessing, setIsProcessing] = useState(false);

  const sampleQueries = [
    "I want to learn Python programming for beginners.",
    "Recommend books about artificial intelligence and machine learning.",
    "I am interested in database management systems.",
    "I want a book about communication skills.",
    "Recommend something about robotics and automation.",
    "I want to learn electronics and embedded systems.",
    "Suggest books related to data science."
  ];

  const edgeCases = [
    { label: 'Empty Input', query: '' },
    { label: 'Stop Words Only', query: 'what is the book for me and you' },
    { label: 'Out of Vocabulary', query: 'quantum xylophone astronaut mars' },
    { label: 'Special Chars', query: '!@#$%^&*()_+=-<>?' },
    { label: 'Mixed-Case Input', query: 'pYtHoN pRoGrAmMiNg BeGiNnErS' }
  ];

  const handleExecute = (queryText: string = currentQuery) => {
    setIsProcessing(true);
    setTimeout(() => {
      onRunQuery(queryText, topN);
      setIsProcessing(false);
    }, 150);
  };

  const handleSelectSample = (q: string) => {
    setCurrentQuery(q);
    handleExecute(q);
  };

  return (
    <div className="space-y-6">
      {/* Streamlit-Style Query Card */}
      <div className="bg-white rounded-xl border border-stone-200 shadow-sm p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-stone-100">
          <div>
            <h2 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <Search className="w-4 h-4 text-emerald-600" />
              What are you looking for?
            </h2>
            <p className="text-xs text-stone-500">
              Enter your research topic, engineering discipline, or learning objective in conversational language.
            </p>
          </div>

          {/* Top-N Slider Control */}
          <div className="flex items-center gap-3 bg-stone-50 px-3 py-1.5 rounded-lg border border-stone-200">
            <Sliders className="w-3.5 h-3.5 text-stone-500" />
            <label htmlFor="top-n-slider" className="text-xs font-medium text-stone-700 whitespace-nowrap">
              Top-N Results: <span className="font-bold text-emerald-700 font-mono">{topN}</span>
            </label>
            <input
              id="top-n-slider"
              type="range"
              min={1}
              max={10}
              value={topN}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                setTopN(val);
                if (currentQuery) onRunQuery(currentQuery, val);
              }}
              className="w-24 accent-emerald-600 cursor-pointer"
            />
          </div>
        </div>

        {/* Text Area */}
        <div className="space-y-2">
          <textarea
            id="query-input-textarea"
            rows={3}
            value={currentQuery}
            onChange={(e) => setCurrentQuery(e.target.value)}
            placeholder="e.g., I want to learn machine learning for beginners."
            className="w-full text-sm p-3 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 font-sans text-stone-800 placeholder:text-stone-400"
          />

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            {/* Edge Case Buttons */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider mr-1">Edge Cases:</span>
              {edgeCases.map((ec, i) => (
                <button
                  key={i}
                  id={`edge-case-btn-${i}`}
                  onClick={() => handleSelectSample(ec.query)}
                  className="text-[11px] bg-stone-100 hover:bg-stone-200 text-stone-700 px-2 py-0.5 rounded border border-stone-200 transition-colors"
                >
                  {ec.label}
                </button>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2">
              {currentQuery && (
                <button
                  id="clear-query-btn"
                  onClick={() => {
                    setCurrentQuery('');
                    onRunQuery('', topN);
                  }}
                  className="text-xs text-stone-500 hover:text-stone-800 px-2.5 py-1.5 transition-colors"
                >
                  Clear
                </button>
              )}
              <button
                id="recommend-books-btn"
                onClick={() => handleExecute()}
                disabled={isProcessing}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all shadow-sm shadow-emerald-600/20 active:scale-[0.98] disabled:opacity-70"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Processing NLP...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    Recommend Books
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Academic Sample Queries */}
        <div className="pt-2 border-t border-stone-100">
          <div className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider mb-2">
            Academic Benchmark Queries (from Syllabus Test Cases):
          </div>
          <div className="flex flex-wrap gap-1.5">
            {sampleQueries.map((sq, idx) => (
              <button
                key={idx}
                id={`sample-query-${idx}`}
                onClick={() => handleSelectSample(sq)}
                className={`text-xs px-2.5 py-1 rounded-md border text-left transition-all ${
                  currentQuery === sq
                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-medium'
                    : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100 hover:border-stone-300'
                }`}
              >
                "{sq}"
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Results Section */}
      {currentResponse && (
        <div className="space-y-4">
          {/* Status Message Banner */}
          {currentResponse.status === 'success' && (
            <div className="flex items-center justify-between bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-3 rounded-xl text-xs">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{currentResponse.message}</span>
                {currentResponse.query_details && (
                  <span className="text-emerald-700 font-mono text-[11px] bg-emerald-100/70 px-2 py-0.5 rounded">
                    Active Features: {currentResponse.query_details.active_features.join(', ')}
                  </span>
                )}
              </div>
              <button
                id="inspect-nlp-btn"
                onClick={onInspectPipeline}
                className="flex items-center gap-1.5 font-semibold text-emerald-700 hover:text-emerald-900 underline ml-3 shrink-0"
              >
                <Layers className="w-3.5 h-3.5" />
                Inspect NLP Pipeline
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          )}

          {currentResponse.status === 'empty_query' && (
            <div className="flex items-center gap-2.5 bg-amber-50 border border-amber-200 text-amber-900 px-4 py-3 rounded-xl text-xs">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{currentResponse.message}</span>
            </div>
          )}

          {currentResponse.status === 'stopwords_only' && (
            <div className="flex items-center gap-2.5 bg-blue-50 border border-blue-200 text-blue-900 px-4 py-3 rounded-xl text-xs">
              <AlertCircle className="w-4 h-4 text-blue-600 shrink-0" />
              <div>
                <strong>Stop-word Filter Activated: </strong>
                {currentResponse.message}
              </div>
            </div>
          )}

          {currentResponse.status === 'no_matches' && (
            <div className="flex items-center gap-2.5 bg-stone-100 border border-stone-300 text-stone-800 px-4 py-3 rounded-xl text-xs">
              <AlertCircle className="w-4 h-4 text-stone-600 shrink-0" />
              <span>{currentResponse.message}</span>
            </div>
          )}

          {/* Recommendations Cards Grid */}
          {currentResponse.recommendations.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                  Top-{currentResponse.recommendations.length} Recommended Books (Ranked by Cosine Similarity)
                </h3>
                <span className="text-xs text-stone-500">
                  Cosine Metric Range: [0.0 - 1.0]
                </span>
              </div>

              <div className="grid grid-cols-1 gap-3">
                {currentResponse.recommendations.map((rec, index) => {
                  const percent = Math.round(rec.similarity_score * 100);
                  return (
                    <div
                      key={rec.book_id}
                      id={`recommendation-card-${index + 1}`}
                      className="bg-white rounded-xl border border-stone-200 p-4.5 shadow-sm hover:border-emerald-300 transition-all space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <span className="w-7 h-7 rounded-lg bg-stone-900 text-white font-mono font-bold text-xs flex items-center justify-center shrink-0">
                            #{index + 1}
                          </span>
                          <div>
                            <h4 className="text-sm font-bold text-stone-900">
                              {rec.title}
                            </h4>
                            <p className="text-xs text-stone-600">
                              By <span className="font-medium text-stone-800">{rec.author}</span>
                            </p>
                          </div>
                        </div>

                        {/* Similarity Badge */}
                        <div className="flex items-center gap-2 sm:self-auto self-start">
                          <span className="text-xs text-stone-500 font-medium">Similarity:</span>
                          <div className="flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-md">
                            <span className="font-mono font-bold text-xs text-emerald-800">
                              {rec.similarity_score.toFixed(4)}
                            </span>
                            <span className="text-[10px] text-emerald-600 font-semibold">
                              ({percent}%)
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Description */}
                      <p className="text-xs text-stone-700 leading-relaxed bg-stone-50/70 p-3 rounded-lg border border-stone-100">
                        {rec.description}
                      </p>

                      {/* Meta Chips */}
                      <div className="flex flex-wrap items-center gap-2 text-[11px] pt-1">
                        <span className="bg-stone-100 text-stone-700 px-2.5 py-0.5 rounded font-medium border border-stone-200">
                          Genre: <strong className="text-stone-900">{rec.genre}</strong>
                        </span>
                        <span className="text-stone-500 font-mono">
                          ISBN: {rec.isbn}
                        </span>
                        <span className="text-stone-400">•</span>
                        <span className="text-stone-500">
                          Year: {rec.publication_year}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
