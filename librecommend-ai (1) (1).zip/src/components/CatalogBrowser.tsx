import React, { useState } from 'react';
import { Database, Search, Filter, BookOpen } from 'lucide-react';
import { Book } from '../types';

interface CatalogBrowserProps {
  books: Book[];
  onSelectBookForQuery: (bookTitle: string) => void;
}

export const CatalogBrowser: React.FC<CatalogBrowserProps> = ({
  books,
  onSelectBookForQuery
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('ALL');

  const genres = ['ALL', ...Array.from(new Set(books.map(b => b.genre))).sort()];

  const filteredBooks = books.filter(book => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.genre.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesGenre = selectedGenre === 'ALL' || book.genre === selectedGenre;

    return matchesSearch && matchesGenre;
  });

  return (
    <div className="space-y-5">
      {/* Header & Controls */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-600" />
              Academic Library Dataset Catalog
            </h2>
            <p className="text-xs text-stone-500">
              Legitimate catalog of 60 published textbooks and references sourced from Open Library and standard university syllabi.
            </p>
          </div>
          <span className="text-xs font-mono font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1 rounded-lg">
            Showing {filteredBooks.length} of {books.length} Books
          </span>
        </div>

        {/* Search & Genre Filters */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by title, author, description, or keyword..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-stone-300 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-stone-400 shrink-0" />
            <select
              value={selectedGenre}
              onChange={(e) => setSelectedGenre(e.target.value)}
              className="text-xs py-2 px-3 rounded-lg border border-stone-300 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 font-medium text-stone-700"
            >
              {genres.map(g => (
                <option key={g} value={g}>
                  {g === 'ALL' ? 'All Disciplines & Genres' : g}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Book Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filteredBooks.map((book) => (
          <div
            key={book.book_id}
            className="bg-white rounded-xl border border-stone-200 p-4 shadow-sm hover:border-stone-300 transition-all flex flex-col justify-between space-y-3"
          >
            <div className="space-y-2">
              <div className="flex items-start justify-between gap-2">
                <span className="text-[10px] font-mono text-stone-600 bg-stone-100 px-2 py-0.5 rounded border border-stone-200">
                  ID: #{book.book_id}
                </span>
                <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200">
                  {book.genre}
                </span>
              </div>

              <div>
                <h3 className="text-sm font-bold text-stone-900 leading-snug">
                  {book.title}
                </h3>
                <p className="text-xs text-stone-600">
                  Author: <span className="font-medium text-stone-800">{book.author}</span>
                </p>
              </div>

              <p className="text-xs text-stone-700 line-clamp-3 leading-relaxed">
                {book.description}
              </p>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-stone-100 text-[11px]">
              <span className="text-stone-500 font-mono">
                ISBN: {book.isbn} • {book.publication_year}
              </span>
              <button
                onClick={() => onSelectBookForQuery(`Recommend books similar to ${book.title}`)}
                className="flex items-center gap-1 text-emerald-700 hover:text-emerald-900 font-semibold"
              >
                <BookOpen className="w-3 h-3" />
                Find Similar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
