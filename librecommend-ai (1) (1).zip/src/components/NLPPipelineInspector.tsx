import React from 'react';
import { Layers, ArrowDown, Check, Filter, Scissors, Hash, Activity } from 'lucide-react';
import { NLPPreprocessingSteps } from '../types';

interface NLPPipelineInspectorProps {
  query: string;
  steps: NLPPreprocessingSteps | null;
  activeFeatures: string[];
  onSelectSampleQuery: (q: string) => void;
}

export const NLPPipelineInspector: React.FC<NLPPipelineInspectorProps> = ({
  query,
  steps,
  activeFeatures,
  onSelectSampleQuery
}) => {
  if (!steps || !query) {
    return (
      <div className="bg-white rounded-xl border border-stone-200 p-8 text-center space-y-3">
        <Layers className="w-10 h-10 text-stone-400 mx-auto" />
        <h3 className="text-sm font-bold text-stone-800">No Query Processed Yet</h3>
        <p className="text-xs text-stone-500 max-w-md mx-auto">
          Enter a natural language query in the Recommendation System tab or select an academic sample below to inspect each stage of the NLP pipeline.
        </p>
        <div className="flex flex-wrap justify-center gap-2 pt-2">
          <button
            onClick={() => onSelectSampleQuery("I want to learn Python programming for beginners.")}
            className="text-xs bg-emerald-50 text-emerald-800 border border-emerald-300 px-3 py-1.5 rounded-lg hover:bg-emerald-100 font-medium"
          >
            Load: "I want to learn Python programming for beginners."
          </button>
          <button
            onClick={() => onSelectSampleQuery("Recommend books about artificial intelligence and machine learning.")}
            className="text-xs bg-stone-100 text-stone-700 border border-stone-200 px-3 py-1.5 rounded-lg hover:bg-stone-200 font-medium"
          >
            Load: "Recommend books about AI and machine learning."
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-sm space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-stone-900 flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-600" />
            Natural Language Processing Pipeline Breakdown
          </h2>
          <span className="text-xs font-mono bg-stone-100 text-stone-700 px-2.5 py-1 rounded-md border border-stone-200">
            Tokens: {steps.token_count} | Kept Features: {steps.stemmed_tokens.length}
          </span>
        </div>
        <p className="text-xs text-stone-500">
          This inspector visualizes each mathematical transformation applied to the user's input before vector space projection and cosine similarity scoring.
        </p>
      </div>

      {/* Sequential Pipeline Stages */}
      <div className="space-y-4">
        {/* Stage 1: Raw Query */}
        <div className="bg-white rounded-xl border border-stone-200 p-4.5 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-900 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-stone-100 text-stone-700 flex items-center justify-center text-[11px] font-mono">1</span>
              Raw Natural-Language Query
            </span>
            <span className="text-[11px] text-stone-500 font-mono">Input String</span>
          </div>
          <div className="bg-stone-50 border border-stone-200 p-3 rounded-lg font-mono text-xs text-stone-900">
            "{steps.original_text}"
          </div>
        </div>

        <div className="flex justify-center -my-2">
          <ArrowDown className="w-4 h-4 text-stone-400" />
        </div>

        {/* Stage 2: Lowercasing & Punctuation Stripping */}
        <div className="bg-white rounded-xl border border-stone-200 p-4.5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-900 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-[11px] font-mono">2</span>
              Case Normalization & Punctuation Removal
            </span>
            <span className="text-[11px] text-stone-500 font-mono">Regex: [^\w\s]</span>
          </div>
          <p className="text-xs text-stone-600">
            Converts all characters to lowercase to eliminate case sensitivity and removes non-alphanumeric noise symbols.
          </p>
          <div className="bg-stone-50 border border-stone-200 p-3 rounded-lg font-mono text-xs text-stone-900">
            "{steps.punctuation_removed}"
          </div>
        </div>

        <div className="flex justify-center -my-2">
          <ArrowDown className="w-4 h-4 text-stone-400" />
        </div>

        {/* Stage 3: Tokenization */}
        <div className="bg-white rounded-xl border border-stone-200 p-4.5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-900 flex items-center gap-2">
              <Scissors className="w-4 h-4 text-emerald-600" />
              Stage 3: Tokenization
            </span>
            <span className="text-[11px] text-stone-500 font-mono">{steps.tokens.length} Raw Tokens</span>
          </div>
          <p className="text-xs text-stone-600">
            Splits the continuous string into discrete word tokens based on whitespace boundaries.
          </p>
          <div className="flex flex-wrap gap-1.5 p-3 bg-stone-50 rounded-lg border border-stone-200">
            {steps.tokens.map((token, idx) => (
              <span key={idx} className="bg-white border border-stone-300 text-stone-800 px-2 py-0.5 rounded font-mono text-xs shadow-2xs">
                "{token}"
              </span>
            ))}
          </div>
        </div>

        <div className="flex justify-center -my-2">
          <ArrowDown className="w-4 h-4 text-stone-400" />
        </div>

        {/* Stage 4: Stop-Word Filtering */}
        <div className="bg-white rounded-xl border border-stone-200 p-4.5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-900 flex items-center gap-2">
              <Filter className="w-4 h-4 text-amber-600" />
              Stage 4: Stop-Word Filtering
            </span>
            <span className="text-[11px] text-amber-700 font-mono bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
              {steps.removed_stopwords.length} Filtered
            </span>
          </div>
          <p className="text-xs text-stone-600">
            Discards high-frequency non-informative grammatical terms (e.g., "for", "to", "i") and conversational query noise ("want", "recommend").
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-lg space-y-1.5">
              <div className="text-[11px] font-bold text-rose-800 uppercase tracking-wider">
                Discarded Stop Words:
              </div>
              <div className="flex flex-wrap gap-1">
                {steps.removed_stopwords.length > 0 ? (
                  steps.removed_stopwords.map((sw, i) => (
                    <span key={i} className="line-through bg-rose-100 text-rose-800 px-2 py-0.5 rounded text-xs font-mono">
                      {sw}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-stone-400 italic">No stop words found</span>
                )}
              </div>
            </div>

            <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-lg space-y-1.5">
              <div className="text-[11px] font-bold text-emerald-800 uppercase tracking-wider">
                Retained Informative Words:
              </div>
              <div className="flex flex-wrap gap-1">
                {steps.filtered_tokens.map((fw, i) => (
                  <span key={i} className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded text-xs font-mono font-medium">
                    {fw}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center -my-2">
          <ArrowDown className="w-4 h-4 text-stone-400" />
        </div>

        {/* Stage 5: Stemming */}
        <div className="bg-white rounded-xl border border-stone-200 p-4.5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-900 flex items-center gap-2">
              <Hash className="w-4 h-4 text-purple-600" />
              Stage 5: Morphological Stemming (Root Normalization)
            </span>
            <span className="text-[11px] text-purple-700 font-mono bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
              Suffix Reduction
            </span>
          </div>
          <p className="text-xs text-stone-600">
            Reduces morphological word variants down to their shared semantic root so that "programming", "programs", and "programmer" map to the same root feature.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
            {steps.filtered_tokens.map((token, i) => {
              const stem = steps.stemmed_tokens[i];
              const changed = token !== stem;
              return (
                <div key={i} className="flex items-center justify-between p-2.5 rounded-lg border border-stone-200 bg-stone-50 font-mono text-xs">
                  <span className="text-stone-600">{token}</span>
                  <span className="text-stone-400">→</span>
                  <span className={`font-bold ${changed ? 'text-purple-700 underline' : 'text-stone-800'}`}>
                    {stem}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex justify-center -my-2">
          <ArrowDown className="w-4 h-4 text-stone-400" />
        </div>

        {/* Stage 6: TF-IDF Vectorization & Cosine Similarity */}
        <div className="bg-white rounded-xl border border-stone-200 p-4.5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-stone-900 flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-600" />
              Stage 6: TF-IDF Projection & Cosine Similarity
            </span>
            <span className="text-[11px] text-stone-500 font-mono">Vector Space Model</span>
          </div>
          <div className="p-3 bg-stone-900 text-stone-100 rounded-lg space-y-2 text-xs font-mono">
            <div className="text-emerald-400 font-semibold">// TF-IDF & Cosine Similarity Formulas:</div>
            <div>TF(t, d) = f(t, d) / sum(f(t', d))</div>
            <div>IDF(t) = ln((1 + N) / (1 + DF(t))) + 1</div>
            <div>Cosine_Sim(Q, D) = sum(Q[i] * D[i]) / (||Q||_2 * ||D||_2)</div>
          </div>
          <div className="space-y-1">
            <div className="text-xs font-semibold text-stone-800">
              Active Vocabulary Features in Query Vector:
            </div>
            <div className="flex flex-wrap gap-1.5">
              {activeFeatures.length > 0 ? (
                activeFeatures.map((f, i) => (
                  <span key={i} className="bg-emerald-50 border border-emerald-300 text-emerald-800 font-mono text-xs px-2.5 py-1 rounded">
                    {f}
                  </span>
                ))
              ) : (
                <span className="text-xs text-stone-500 italic">No features active</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
