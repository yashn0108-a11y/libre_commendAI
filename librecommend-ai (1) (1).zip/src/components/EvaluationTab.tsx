import React from 'react';
import { BarChart3, CheckCircle2, Target, Award, Compass, FileText } from 'lucide-react';

export const EvaluationTab: React.FC = () => {
  const benchmarkResults = [
    {
      id: 1,
      query: "I want to learn Python programming for beginners.",
      genres: "Computer Science",
      topBook: "Python Crash Course",
      relevantInTop5: 3,
      precision5: "60.0%",
      recall5: "27.3%",
      hitRate: "1.0",
      mrr: "1.0000"
    },
    {
      id: 2,
      query: "Recommend books about artificial intelligence and machine learning.",
      genres: "Machine Learning, Artificial Intelligence",
      topBook: "Artificial Intelligence: A Modern Approach",
      relevantInTop5: 5,
      precision5: "100.0%",
      recall5: "83.3%",
      hitRate: "1.0",
      mrr: "1.0000"
    },
    {
      id: 3,
      query: "I am interested in database management systems.",
      genres: "Database Systems",
      topBook: "Fundamentals of Database Systems",
      relevantInTop5: 4,
      precision5: "80.0%",
      recall5: "100.0%",
      hitRate: "1.0",
      mrr: "1.0000"
    },
    {
      id: 4,
      query: "I want a book about communication skills.",
      genres: "Communication Skills",
      topBook: "Nonviolent Communication: A Language of Life",
      relevantInTop5: 4,
      precision5: "80.0%",
      recall5: "100.0%",
      hitRate: "1.0",
      mrr: "1.0000"
    },
    {
      id: 5,
      query: "Recommend something about robotics and automation.",
      genres: "Robotics",
      topBook: "Automate the Boring Stuff with Python",
      relevantInTop5: 4,
      precision5: "80.0%",
      recall5: "100.0%",
      hitRate: "1.0",
      mrr: "0.5000"
    },
    {
      id: 6,
      query: "I want to learn electronics and embedded systems.",
      genres: "Electronics, Embedded Systems",
      topBook: "Making Embedded Systems",
      relevantInTop5: 2,
      precision5: "40.0%",
      recall5: "22.2%",
      hitRate: "1.0",
      mrr: "1.0000"
    },
    {
      id: 7,
      query: "Suggest books related to data science.",
      genres: "Data Science, Machine Learning",
      topBook: "Data Science from Scratch",
      relevantInTop5: 3,
      precision5: "60.0%",
      recall5: "42.9%",
      hitRate: "1.0",
      mrr: "1.0000"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Title Card */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-sm space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-stone-900 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-emerald-600" />
            Empirical Evaluation & Performance Metrics (K = 5)
          </h2>
          <span className="text-xs font-mono bg-stone-100 text-stone-700 px-2.5 py-1 rounded-md border border-stone-200">
            Source: output/evaluation_results.txt
          </span>
        </div>
        <p className="text-xs text-stone-500">
          Evaluated using standard Information Retrieval metrics across 7 curriculum benchmark queries with labeled relevance categories.
        </p>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-stone-500">
            <span className="text-xs font-medium uppercase tracking-wider">Mean Precision@5</span>
            <Target className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-stone-900">71.43%</div>
          <p className="text-[11px] text-stone-500">
            Fraction of top-5 recommendations that directly belong to target domain.
          </p>
        </div>

        {/* Metric 2 */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-stone-500">
            <span className="text-xs font-medium uppercase tracking-wider">Mean Recall@5</span>
            <Compass className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-stone-900">67.96%</div>
          <p className="text-[11px] text-stone-500">
            Fraction of total catalog books in the discipline successfully retrieved.
          </p>
        </div>

        {/* Metric 3 */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-stone-500">
            <span className="text-xs font-medium uppercase tracking-wider">Hit Rate@5</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-stone-900">100.0%</div>
          <p className="text-[11px] text-stone-500">
            Every test query returned at least one relevant book in the top 5 results.
          </p>
        </div>

        {/* Metric 4 */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-sm space-y-1">
          <div className="flex items-center justify-between text-stone-500">
            <span className="text-xs font-medium uppercase tracking-wider">MRR Score</span>
            <Award className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-stone-900">0.9286</div>
          <p className="text-[11px] text-stone-500">
            Mean Reciprocal Rank: First relevant item was found at Rank 1 in 6 of 7 queries.
          </p>
        </div>
      </div>

      {/* Mathematical Formulation Card */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-sm space-y-3">
        <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
          <FileText className="w-4 h-4 text-emerald-600" />
          Academic Information Retrieval Formulations
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="bg-stone-50 p-3 rounded-lg border border-stone-200 font-mono space-y-1">
            <div className="font-bold text-emerald-800">Precision@K:</div>
            <div className="text-stone-700">P@K = |Relevant ∩ TopK| / K</div>
            <p className="text-[10px] text-stone-500 font-sans">
              Measures recommendation purity within top K items.
            </p>
          </div>

          <div className="bg-stone-50 p-3 rounded-lg border border-stone-200 font-mono space-y-1">
            <div className="font-bold text-teal-800">Recall@K:</div>
            <div className="text-stone-700">R@K = |Relevant ∩ TopK| / |Catalog Relevant|</div>
            <p className="text-[10px] text-stone-500 font-sans">
              Measures coverage of all books in the category.
            </p>
          </div>

          <div className="bg-stone-50 p-3 rounded-lg border border-stone-200 font-mono space-y-1">
            <div className="font-bold text-purple-800">Mean Reciprocal Rank (MRR):</div>
            <div className="text-stone-700">MRR = (1 / |Q|) * Σ (1 / rank_i)</div>
            <p className="text-[10px] text-stone-500 font-sans">
              Reward for placing the first relevant hit at the top.
            </p>
          </div>
        </div>
      </div>

      {/* Per-Query Breakdown Table */}
      <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden space-y-2">
        <div className="p-4 border-b border-stone-200 bg-stone-50/50 flex items-center justify-between">
          <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
            Per-Query Benchmark Evaluation Table
          </h3>
          <span className="text-[11px] text-stone-500 font-mono">
            7 Test Queries Evaluated
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 text-stone-600 border-b border-stone-200 font-medium text-[11px]">
              <tr>
                <th className="py-2.5 px-3">#</th>
                <th className="py-2.5 px-3">Test Query</th>
                <th className="py-2.5 px-3">Target Discipline</th>
                <th className="py-2.5 px-3">Top Book Retrieved</th>
                <th className="py-2.5 px-3 text-center">P@5</th>
                <th className="py-2.5 px-3 text-center">R@5</th>
                <th className="py-2.5 px-3 text-center">MRR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 font-sans">
              {benchmarkResults.map(row => (
                <tr key={row.id} className="hover:bg-stone-50/80 transition-colors">
                  <td className="py-2.5 px-3 font-mono text-stone-500">Q{row.id}</td>
                  <td className="py-2.5 px-3 font-medium text-stone-900">"{row.query}"</td>
                  <td className="py-2.5 px-3">
                    <span className="bg-stone-100 text-stone-700 px-2 py-0.5 rounded text-[11px]">
                      {row.genres}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-stone-800 font-medium">
                    {row.topBook}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono font-semibold text-emerald-700">
                    {row.precision5}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono text-stone-600">
                    {row.recall5}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono font-bold text-purple-700">
                    {row.mrr}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
