import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Clock, GitBranch, Cpu, Search } from 'lucide-react';

export const VivaPrepTab: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [vivaSearch, setVivaSearch] = useState<string>('');

  const vivaQuestions = [
    {
      category: 'NLP Basics',
      q: 'What is Natural Language Processing (NLP) and why is it required in this project?',
      a: 'NLP is the branch of Artificial Intelligence that enables computers to understand, interpret, and manipulate human language. In this library recommendation system, students search for learning materials using unstructured, colloquial phrasing (e.g., "I want to learn machine learning for beginners"). NLP is required to clean, normalize, tokenize, and transform this unstructured input into mathematical vectors that can be compared against textbook metadata.'
    },
    {
      category: 'NLP Basics',
      q: 'What is tokenization and why is it essential?',
      a: 'Tokenization is the process of splitting continuous text into discrete semantic units (words, terms, or symbols). It is the indispensable first step for vectorization because computers cannot process continuous paragraphs without first identifying individual lexical items.'
    },
    {
      category: 'NLP Basics',
      q: 'What is stop-word removal and how does it prevent noise?',
      a: 'Stop words are high-frequency grammatical function words (e.g., "the", "is", "at", "which", "for") and conversational filler words (e.g., "want", "recommend", "book"). They convey minimal discriminative content. Filtering them prevents common words from artificially inflating similarity scores between unrelated books.'
    },
    {
      category: 'NLP Basics',
      q: 'What is the difference between stemming and lemmatization?',
      a: 'Stemming uses heuristic, rule-based suffix truncation (e.g., chopping -ing, -ed, -s) to produce a base stem that may not be an authentic dictionary word (e.g., "computation" -> "comput"). Lemmatization utilizes morphological vocabulary and grammatical part-of-speech context to return the true root lemma (e.g., "better" -> "good"). Stemming was chosen here for fast, lightweight deterministic processing.'
    },
    {
      category: 'TF-IDF',
      q: 'What is Term Frequency (TF)?',
      a: 'Term Frequency measures how frequently a term t appears within a specific document d: TF(t, d) = count(t, d) / total_words(d). It represents local term importance within a single book description.'
    },
    {
      category: 'TF-IDF',
      q: 'What is Inverse Document Frequency (IDF)?',
      a: 'Inverse Document Frequency quantifies how rare or informative a term is across the entire catalog: IDF(t) = ln((1 + N) / (1 + DF(t))) + 1. If a word appears in every single book, its IDF is near zero; if it appears in only 1 or 2 books (such as "robotics" or "sql"), its IDF score is high.'
    },
    {
      category: 'TF-IDF',
      q: 'Why is TF-IDF superior to raw word counts (Bag-of-Words)?',
      a: 'Raw word counts favor lengthy documents and ubiquitous words. TF-IDF balances intra-document frequency with corpus-wide uniqueness, rewarding terms that uniquely characterize a specific book.'
    },
    {
      category: 'TF-IDF',
      q: 'What are the main limitations of TF-IDF?',
      a: 'TF-IDF is a lexical matching model (Bag-of-Words). It assumes term independence, ignores word order and syntactic grammar, and cannot recognize semantic synonyms (e.g., "physician" vs. "doctor") unless they share a morphological root stem.'
    },
    {
      category: 'Cosine Similarity',
      q: 'What is Cosine Similarity and why is it used instead of Euclidean distance?',
      a: 'Cosine Similarity measures the cosine of the angle between two multidimensional vectors: Cosine_Sim(Q, D) = (Q · D) / (||Q|| * ||D||). Unlike Euclidean distance, which is sensitive to vector length (penalizing long book descriptions against short queries), Cosine Similarity measures directional orientation regardless of magnitude.'
    },
    {
      category: 'Cosine Similarity',
      q: 'What do similarity scores of 0, 1, and negative values indicate?',
      a: 'Scores range from 0.0 to 1.0. A score of 1.0 indicates identical relative word distributions; 0.0 indicates orthogonal vectors with no shared vocabulary terms. Negative scores do not occur in text processing because TF and IDF are non-negative.'
    },
    {
      category: 'Recommendation',
      q: 'Is this project a supervised machine learning model?',
      a: 'No. This is an unsupervised Information Retrieval and Content-Based Similarity method. It does not use labeled target training pairs or loss backpropagation; it builds an algebraic vector space representation directly from the catalog metadata.'
    },
    {
      category: 'Recommendation',
      q: 'How does the system handle Out-of-Vocabulary (OOV) queries?',
      a: 'When a user enters terms not present in the catalog vocabulary (e.g., "quantum xylophone astronaut"), the transformed query vector has zero non-zero entries. The system detects this edge case and gracefully informs the user that no relevant library matches exist without crashing.'
    },
    {
      category: 'Evaluation',
      q: 'How is Precision@K and Recall@K calculated for recommendation systems?',
      a: 'Precision@K is the ratio of relevant books in the top-K recommendations divided by K (measuring recommendation purity). Recall@K is the number of relevant books retrieved in top-K divided by the total number of relevant books existing in the catalog for that topic (measuring coverage).'
    },
    {
      category: 'Evaluation',
      q: 'What is Mean Reciprocal Rank (MRR)?',
      a: 'MRR evaluates ranking quality by taking the reciprocal rank of the first relevant recommendation across queries: MRR = (1/|Q|) * sum(1 / rank_i). If the first relevant book is at position 1, score is 1.0; if at position 2, score is 0.5. Our system achieved an MRR of 0.9286.'
    },
    {
      category: 'Git & Engineering',
      q: 'What constitutes good Git practice in an academic repository?',
      a: 'Good Git practice involves atomic, descriptive commits tracking genuine development milestones (e.g., dataset ingestion, NLP preprocessing, TF-IDF vectorization, evaluation suite, UI integration), maintaining a clean .gitignore, and documenting complete setup instructions in README.md.'
    }
  ];

  const categories = ['ALL', 'NLP Basics', 'TF-IDF', 'Cosine Similarity', 'Recommendation', 'Evaluation', 'Git & Engineering'];

  const filteredQuestions = vivaQuestions.filter(item => {
    const matchesCat = filterCategory === 'ALL' || item.category === filterCategory;
    const matchesSearch =
      item.q.toLowerCase().includes(vivaSearch.toLowerCase()) ||
      item.a.toLowerCase().includes(vivaSearch.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* 2-Minute Elevator Pitch */}
      <div className="bg-gradient-to-br from-stone-900 to-stone-800 text-stone-100 rounded-xl p-6 shadow-sm space-y-3">
        <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider">
          <Clock className="w-4 h-4" />
          2-Minute Examiner Pitch (Say This at the Start of Viva)
        </div>
        <p className="text-xs sm:text-sm text-stone-300 leading-relaxed font-sans italic border-l-2 border-emerald-500 pl-4 py-1">
          "Respected Examiners, this project develops an AI-Based Smart Library Recommendation System for academic digital catalogs. Standard library search engines rely on strict keyword or author matching, which breaks when students query conceptual topics like 'I want to learn machine learning for beginners'. Our pipeline addresses this using Natural Language Processing: lowercasing, punctuation stripping, tokenization, stop-word removal, and morphological stemming. We construct a 710-term TF-IDF vector space across 60 legitimate textbooks and evaluate user queries via Cosine Similarity. On standard curriculum benchmarks, our system achieved a 100% Hit Rate@5, a Mean Precision@5 of 71.4%, and a Mean Reciprocal Rank of 0.9286, running as a fully responsive, explainable academic web application."
        </p>
      </div>

      {/* 5-Minute Technical Overview */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-sm space-y-3">
        <div className="flex items-center gap-2 text-stone-900 text-xs font-bold uppercase tracking-wider">
          <Cpu className="w-4 h-4 text-emerald-600" />
          5-Minute Technical Architecture Summary
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          <div className="bg-stone-50 p-3.5 rounded-lg border border-stone-200 space-y-1.5">
            <span className="font-bold text-stone-900 block">1. Catalog Ingestion</span>
            <p className="text-stone-600 leading-relaxed text-[11px]">
              Loads 60 legitimate textbooks from Open Library archives across 16 disciplines. Synthesizes a unified document string: Title + Author + Genre + Description.
            </p>
          </div>
          <div className="bg-stone-50 p-3.5 rounded-lg border border-stone-200 space-y-1.5">
            <span className="font-bold text-emerald-900 block">2. NLP & TF-IDF Engine</span>
            <p className="text-stone-600 leading-relaxed text-[11px]">
              Extracts 710 vocabulary terms using lowercasing, punctuation regex, stop-word elimination, and Porter-style suffix stemming. Computes smoothed IDF and L2-normalized vectors.
            </p>
          </div>
          <div className="bg-stone-50 p-3.5 rounded-lg border border-stone-200 space-y-1.5">
            <span className="font-bold text-purple-900 block">3. Similarity & Ranking</span>
            <p className="text-stone-600 leading-relaxed text-[11px]">
              Projects the query into the identical vector space. Cosine dot product computes angular relevance scores [0.0 to 1.0]. Sorts descending to deliver Top-N books.
            </p>
          </div>
        </div>
      </div>

      {/* Search & Category Filter */}
      <div className="bg-white rounded-xl border border-stone-200 p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-stone-900">
              V Semester NLP Viva Q&A Bank ({filteredQuestions.length} Questions)
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search viva questions..."
                value={vivaSearch}
                onChange={(e) => setVivaSearch(e.target.value)}
                className="pl-8 pr-2.5 py-1 text-xs rounded-md border border-stone-300 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`text-[11px] px-2.5 py-1 rounded-md transition-colors ${
                filterCategory === cat
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Accordion List */}
        <div className="space-y-2 pt-2">
          {filteredQuestions.map((item, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="border border-stone-200 rounded-lg overflow-hidden transition-all bg-white"
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  className="w-full text-left p-3.5 flex items-center justify-between gap-3 hover:bg-stone-50/80 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold shrink-0">
                      {item.category}
                    </span>
                    <span className="text-xs font-bold text-stone-900">
                      {item.q}
                    </span>
                  </div>
                  {isOpen ? (
                    <ChevronUp className="w-4 h-4 text-stone-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-stone-400 shrink-0" />
                  )}
                </button>

                {isOpen && (
                  <div className="px-3.5 pb-3.5 pt-1 text-xs text-stone-700 leading-relaxed bg-stone-50/50 border-t border-stone-100">
                    <strong className="text-stone-900 block mb-1">Examiner Answer:</strong>
                    {item.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
