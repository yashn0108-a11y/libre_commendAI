export interface Book {
  book_id: string;
  title: string;
  author: string;
  genre: string;
  description: string;
  isbn: string;
  publication_year: string;
  combined_text?: string;
}

export interface RecommendationResult {
  book_id: string;
  title: string;
  author: string;
  genre: string;
  description: string;
  isbn: string;
  publication_year: string;
  similarity_score: number;
}

export interface NLPPreprocessingSteps {
  original_text: string;
  lowercased: string;
  punctuation_removed: string;
  tokens: string[];
  token_count: number;
  removed_stopwords: string[];
  filtered_tokens: string[];
  stemmed_tokens: string[];
  final_processed_text: string;
}

export interface QueryResponse {
  status: "success" | "empty_query" | "stopwords_only" | "no_matches";
  message: string;
  query_details?: {
    original: string;
    tokens: string[];
    stemmed: string[];
    active_features: string[];
    steps: NLPPreprocessingSteps;
  };
  recommendations: RecommendationResult[];
}

export interface EvaluationQueryMetric {
  query: string;
  target_genres: string[];
  retrieved_count: number;
  relevant_retrieved: number;
  precision_at_k: number;
  recall_at_k: number;
  hit_rate_at_k: number;
  first_hit_rank: number | null;
  reciprocal_rank: number;
  top_book: string;
}

export interface EvaluationReport {
  k: number;
  num_test_queries: number;
  mean_precision_at_k: number;
  mean_recall_at_k: number;
  mean_hit_rate_at_k: number;
  mean_reciprocal_rank_mrr: number;
  query_evaluations: EvaluationQueryMetric[];
}
