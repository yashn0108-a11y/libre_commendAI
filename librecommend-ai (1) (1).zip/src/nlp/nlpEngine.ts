/**
 * Client-Side NLP Engine for AI-Based Smart Library Recommendation System
 * Directly mirrors the Python implementation in source_code/preprocessing.py and source_code/recommendation.py
 */

import { Book, RecommendationResult, NLPPreprocessingSteps, QueryResponse } from '../types';
import booksRawData from '../data/booksData.json';

// Identical stop words list as in Python source_code/preprocessing.py
export const STOP_WORDS = new Set([
  "a", "about", "above", "after", "again", "against", "all", "am", "an", "and",
  "any", "are", "aren't", "as", "at", "be", "because", "been", "before", "being",
  "below", "between", "both", "but", "by", "can't", "cannot", "could", "couldn't",
  "did", "didn't", "do", "does", "doesn't", "doing", "don't", "down", "during",
  "each", "few", "for", "from", "further", "had", "hadn't", "has", "hasn't",
  "have", "haven't", "having", "he", "he'd", "he'll", "he's", "her", "here",
  "here's", "hers", "herself", "him", "himself", "his", "how", "how's", "i",
  "i'd", "i'll", "i'm", "i've", "if", "in", "into", "is", "isn't", "it",
  "it's", "its", "itself", "let's", "me", "more", "most", "mustn't", "my",
  "myself", "no", "nor", "not", "of", "off", "on", "once", "only", "or",
  "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same",
  "shan't", "she", "she'd", "she'll", "she's", "should", "shouldn't", "so",
  "some", "such", "than", "that", "that's", "the", "their", "theirs", "them",
  "themselves", "then", "there", "there's", "these", "they", "they'd", "they'll",
  "they're", "they've", "this", "those", "through", "to", "too", "under",
  "until", "up", "very", "was", "wasn't", "we", "we'd", "we'll", "we're",
  "we've", "were", "weren't", "what", "what's", "when", "when's", "where",
  "where's", "which", "while", "who", "who's", "whom", "why", "why's", "with",
  "won't", "would", "wouldn't", "you", "you'd", "you'll", "you're", "you've",
  "your", "yours", "yourself", "yourselves", "want", "recommend", "suggest",
  "need", "looking", "interested", "please", "book", "books"
]);

// Rule-based Porter-style stemming identical to Python preprocessing.py
const SUFFIX_RULES: [string, string][] = [
  ["sses", "ss"],
  ["ies", "y"],
  ["tional", "tion"],
  ["ation", "ate"],
  ["alism", "al"],
  ["iveness", "ive"],
  ["fulness", "ful"],
  ["ousness", "ous"],
  ["izing", "ize"],
  ["ised", "ise"],
  ["ized", "ize"],
  ["ement", ""],
  ["ment", ""],
  ["able", ""],
  ["ible", ""],
  ["ness", ""],
  ["ting", "t"],
  ["ning", "n"],
  ["ling", "l"],
  ["ring", "r"],
  ["ing", ""],
  ["ted", "t"],
  ["ded", "d"],
  ["ied", "y"],
  ["ed", ""],
  ["ers", "er"],
  ["er", ""],
  ["es", "e"],
  ["s", ""]
];

export function stemWord(word: string): string {
  if (word.length <= 3) return word;
  for (const [suffix, replacement] of SUFFIX_RULES) {
    if (word.endsWith(suffix) && word.length - suffix.length >= 3) {
      return word.slice(0, -suffix.length) + replacement;
    }
  }
  return word;
}

export function preprocessWithSteps(text: string): NLPPreprocessingSteps {
  const original = text || "";
  const lowercased = original.toLowerCase();
  const punctuationRemoved = lowercased.replace(/[^\w\s]/g, " ");
  const rawTokens = punctuationRemoved.split(/\s+/).filter(Boolean);
  
  const removedStopwords: string[] = [];
  const filteredTokens: string[] = [];

  for (const t of rawTokens) {
    if (STOP_WORDS.has(t)) {
      removedStopwords.push(t);
    } else {
      filteredTokens.push(t);
    }
  }

  const stemmedTokens = filteredTokens.map(stemWord);
  const finalProcessed = stemmedTokens.join(" ");

  return {
    original_text: original,
    lowercased,
    punctuation_removed: punctuationRemoved,
    tokens: rawTokens,
    token_count: rawTokens.length,
    removed_stopwords: removedStopwords,
    filtered_tokens: filteredTokens,
    stemmed_tokens: stemmedTokens,
    final_processed_text: finalProcessed
  };
}

export class NLPLibraryEngine {
  books: Book[];
  vocabulary: Map<string, number> = new Map();
  idf: Map<string, number> = new Map();
  bookVectors: Map<string, number>[] = [];

  constructor() {
    this.books = (booksRawData as Book[]).map(b => ({
      ...b,
      combined_text: `${b.title} ${b.author} ${b.genre} ${b.description}`
    }));
    this.initializeCorpus();
  }

  private initializeCorpus() {
    const N = this.books.length;
    const docFrequency = new Map<string, number>();

    const tokenizedDocs: string[][] = [];

    for (const book of this.books) {
      const steps = preprocessWithSteps(book.combined_text || "");
      const tokens = steps.stemmed_tokens;
      tokenizedDocs.push(tokens);

      const uniqueTerms = new Set(tokens);
      for (const term of uniqueTerms) {
        docFrequency.set(term, (docFrequency.get(term) || 0) + 1);
      }
    }

    const sortedTerms = Array.from(docFrequency.keys()).sort();
    sortedTerms.forEach((term, index) => {
      this.vocabulary.set(term, index);
      const df = docFrequency.get(term) || 1;
      // Smooth IDF: ln((1 + N) / (1 + DF)) + 1
      const idfScore = Math.log((1 + N) / (1 + df)) + 1.0;
      this.idf.set(term, idfScore);
    });

    // Vectorize each book with L2 normalization
    this.bookVectors = tokenizedDocs.map(tokens => this.vectorizeTokens(tokens));
  }

  private vectorizeTokens(tokens: string[]): Map<string, number> {
    if (tokens.length === 0) return new Map();

    const tfCounts = new Map<string, number>();
    for (const t of tokens) {
      tfCounts.set(t, (tfCounts.get(t) || 0) + 1);
    }

    const totalTerms = tokens.length;
    const vector = new Map<string, number>();
    let sumSq = 0;

    for (const [term, count] of tfCounts.entries()) {
      if (this.vocabulary.has(term)) {
        const tf = count / totalTerms;
        const idfVal = this.idf.get(term) || 1.0;
        const weight = tf * idfVal;
        vector.set(term, weight);
        sumSq += weight * weight;
      }
    }

    const l2Norm = Math.sqrt(sumSq);
    if (l2Norm > 0) {
      for (const [term, weight] of vector.entries()) {
        vector.set(term, weight / l2Norm);
      }
    }

    return vector;
  }

  recommend(query: string, topN: number = 5): QueryResponse {
    if (!query || !query.trim()) {
      return {
        status: "empty_query",
        message: "Please enter a search query.",
        recommendations: []
      };
    }

    const steps = preprocessWithSteps(query);
    if (steps.stemmed_tokens.length === 0) {
      return {
        status: "stopwords_only",
        message: "Your query contained only common stop words or conversational phrases. Please include specific book subjects, topics, or authors.",
        query_details: {
          original: query,
          tokens: steps.tokens,
          stemmed: steps.stemmed_tokens,
          active_features: [],
          steps
        },
        recommendations: []
      };
    }

    const queryVector = this.vectorizeTokens(steps.stemmed_tokens);
    const activeFeatures = Array.from(queryVector.keys());

    if (activeFeatures.length === 0) {
      return {
        status: "no_matches",
        message: "No relevant matches found in the library catalog for the given terms. Try using different or broader keywords.",
        query_details: {
          original: query,
          tokens: steps.tokens,
          stemmed: steps.stemmed_tokens,
          active_features: [],
          steps
        },
        recommendations: []
      };
    }

    // Compute Cosine Similarity
    const scoredBooks: { book: Book; score: number }[] = [];
    for (let i = 0; i < this.books.length; i++) {
      const bookVec = this.bookVectors[i];
      let dotProduct = 0;

      for (const [term, qWeight] of queryVector.entries()) {
        const bWeight = bookVec.get(term) || 0;
        dotProduct += qWeight * bWeight;
      }

      if (dotProduct > 0.0001) {
        scoredBooks.push({
          book: this.books[i],
          score: Math.round(dotProduct * 10000) / 10000
        });
      }
    }

    scoredBooks.sort((a, b) => b.score - a.score);

    const topResults: RecommendationResult[] = scoredBooks.slice(0, topN).map(item => ({
      book_id: item.book.book_id,
      title: item.book.title,
      author: item.book.author,
      genre: item.book.genre,
      description: item.book.description,
      isbn: item.book.isbn,
      publication_year: item.book.publication_year,
      similarity_score: item.score
    }));

    if (topResults.length === 0) {
      return {
        status: "no_matches",
        message: "No books in the library met the relevance threshold for this query.",
        query_details: {
          original: query,
          tokens: steps.tokens,
          stemmed: steps.stemmed_tokens,
          active_features: activeFeatures,
          steps
        },
        recommendations: []
      };
    }

    return {
      status: "success",
      message: `Successfully retrieved top ${topResults.length} relevant books.`,
      query_details: {
        original: query,
        tokens: steps.tokens,
        stemmed: steps.stemmed_tokens,
        active_features: activeFeatures,
        steps
      },
      recommendations: topResults
    };
  }
}
