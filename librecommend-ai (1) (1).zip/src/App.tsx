/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { NLPLibraryEngine, preprocessWithSteps } from './nlp/nlpEngine';
import { QueryResponse } from './types';
import { Header } from './components/Header';
import { RecommendationTab } from './components/RecommendationTab';
import { NLPPipelineInspector } from './components/NLPPipelineInspector';
import { CatalogBrowser } from './components/CatalogBrowser';
import { EvaluationTab } from './components/EvaluationTab';
import { VivaPrepTab } from './components/VivaPrepTab';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('recommend');
  const [currentQuery, setCurrentQuery] = useState<string>('I want to learn machine learning for beginners.');
  const [topN, setTopN] = useState<number>(5);
  const [currentResponse, setCurrentResponse] = useState<QueryResponse | null>(null);

  // Initialize NLP Recommender Engine once
  const engine = useMemo(() => new NLPLibraryEngine(), []);

  // Run initial query on mount so examiners see real recommendations immediately
  useEffect(() => {
    const initialRes = engine.recommend(currentQuery, topN);
    setCurrentResponse(initialRes);
  }, [engine]);

  const handleRunQuery = (query: string, n: number) => {
    const res = engine.recommend(query, n);
    setCurrentResponse(res);
    return res;
  };

  const steps = useMemo(() => {
    return currentQuery ? preprocessWithSteps(currentQuery) : null;
  }, [currentQuery]);

  const activeFeatures = currentResponse?.query_details?.active_features || [];

  return (
    <div className="min-h-screen bg-stone-100/70 text-stone-900 flex flex-col font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Academic Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        totalBooks={engine.books.length}
        vocabSize={engine.vocabulary.size}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        {activeTab === 'recommend' && (
          <RecommendationTab
            onRunQuery={handleRunQuery}
            currentResponse={currentResponse}
            currentQuery={currentQuery}
            setCurrentQuery={setCurrentQuery}
            topN={topN}
            setTopN={setTopN}
            onInspectPipeline={() => setActiveTab('pipeline')}
          />
        )}

        {activeTab === 'pipeline' && (
          <NLPPipelineInspector
            query={currentQuery}
            steps={steps}
            activeFeatures={activeFeatures}
            onSelectSampleQuery={(q) => {
              setCurrentQuery(q);
              handleRunQuery(q, topN);
            }}
          />
        )}

        {activeTab === 'catalog' && (
          <CatalogBrowser
            books={engine.books}
            onSelectBookForQuery={(sample) => {
              setCurrentQuery(sample);
              handleRunQuery(sample, topN);
              setActiveTab('recommend');
            }}
          />
        )}

        {activeTab === 'evaluation' && (
          <EvaluationTab />
        )}

        {activeTab === 'viva' && (
          <VivaPrepTab />
        )}
      </main>

      {/* Academic Footer */}
      <footer className="border-t border-stone-200 bg-white py-4 px-4 text-xs text-stone-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            AI-Based Smart Library Recommendation System • Natural Language Processing (ET5M004)
          </div>
          <div className="flex items-center gap-3">
            <span>Student: <strong>Yash N</strong> (ET5M004-NLP-2026)</span>
            <span>•</span>
            <span>V Semester ETC</span>
            <span>•</span>
            <span className="font-mono text-[11px] text-emerald-700 font-semibold">TF-IDF + Cosine Similarity</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
